# Blueprint GenAI: Efficentamento dell'"Analisi Documentale"

## 1. Descrizione del Caso d'Uso
**Categoria:** Assessment & Analysis
**Titolo:** Analisi Documentale
**Ruolo:** Technical Consultant
**Obiettivo Originale (da CSV):** Revisione critica della documentazione tecnica esistente di un sistema per verificarne l'accuratezza, la completezza e l'aderenza agli standard aziendali prima di prendere in carico la gestione operativa.
**Obiettivo GenAI:** Automatizzare l'analisi della documentazione tecnica esistente (PDF, Word, Confluence) estraendo rapidamente discrepanze, mancanze e violazioni delle policy aziendali, generando un report riassuntivo che evidenzia i punti critici.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion e Validazione Documentale Tramite Chatbot
L'utente carica i documenti tecnici all'interno di un'interfaccia chat familiare (Teams), chiedendo al bot di valutare il grado di aderenza agli standard e la completezza delle informazioni.
*   **Tool Principale Consigliato:** Microsoft Copilot Studio (per pubblicazione su Microsoft Teams)
*   **Alternative:** 1. Accenture Amethyst, 2. ChatGPT Agent (Enterprise)
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4 o Google Gemini 3.1 Pro (ottimali per finestre di contesto ampie e analisi documentale accurata).
*   **Modalità di Utilizzo:** Configurazione di un bot in Teams. L'LLM viene istruito preventivamente tramite un System Prompt.
    *Bozza del System Prompt:*
    ```markdown
    Sei un Revisore Tecnico Senior per un'azienda Enterprise.
    Il tuo compito è analizzare la documentazione tecnica caricata dall'utente.
    Devi verificare:
    1. Completezza (ci sono sezioni mancanti come Architettura, Network, Sicurezza, Backup?).
    2. Accuratezza e chiarezza delle informazioni tecniche presenti.
    3. Aderenza agli standard (es. presenza di schemi aggiornati, convenzioni di naming, descrizioni dei flussi).
    Restituisci un report strutturato in:
    - Punteggio di adeguatezza (0-10)
    - Lacune Trovate (bullet points chiari e concisi)
    - Violazioni di Policy/Standard
    - 5 Domande cruciali da porre al team uscente per completare il passaggio di consegne.
    ```
*   **Azione Umana Richiesta:** Il Technical Consultant revisiona il report generato, incrociando i dubbi sollevati dall'AI con la lettura rapida delle sezioni indicate, prima di richiedere integrazioni formali al team uscente.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 8 ore (lettura profonda, annotazione e stesura verbale)
    *   *Tempo To-Be (GenAI):* 30 minuti
    *   *Risparmio %:* 93%
    *   *Motivazione:* L'AI esamina centinaia di pagine in pochi secondi, fungendo da "motore di ricerca semantico" che evidenzia solo ciò che manca o che risulta ambiguo, azzerando il tempo di lettura lineare e passiva.

## 3. Descrizione del Flusso Logico
Il Technical Consultant, incaricato di prendere in gestione operativa un nuovo sistema, riceve la documentazione tecnica (spesso prolissa e non strutturata). Accede direttamente a Microsoft Teams, apre la chat con l'assistente "Tech Doc Reviewer", allega i file documentali e avvia l'analisi. Il bot elabora i documenti confrontandoli con i parametri del System Prompt e restituisce un summary con le aree scoperte. Il Consultant supervisiona l'output, estrapola le domande generate dall'AI e le utilizza per guidare l'incontro di handover con il team uscente, garantendo un passaggio di consegne preciso e completo.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    A[Technical Consultant] -->|Interagisce e allega File| B[Microsoft Teams Client]
    B -->|Inoltra richiesta| C[Copilot Studio Bot]
    C -->|API Call + RAG| D[LLM - GPT-5.4 / Gemini 3.1 Pro]
    D -->|Ritorna Analisi| C
    C -->|Visualizza Report| B
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    A[Ricezione Documentazione as-is] --> B[Upload file su Teams Bot]
    B --> C{L'LLM rileva mancanze?}
    C -->|Sì| D[Generazione Report Difformità e Domande]
    C -->|No| E[Generazione Report OK]
    D --> F[Review Umana del Report]
    E --> F
    F --> G[Meeting di handover con team uscente]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant User as Technical Consultant
    participant Teams as Microsoft Teams
    participant Bot as Copilot Studio (Bot)
    participant LLM as GPT-5.4 / Gemini 3.1 Pro

    User->>Teams: Allega documenti (PDF/Word) e chiede Review
    Teams->>Bot: Inoltra payload (File + Query)
    Bot->>LLM: Invia System Prompt + Contenuto File
    LLM-->>Bot: Restituisce Report Strutturato (Lacune, Policy)
    Bot-->>Teams: Renderizza risposta formattata
    Teams-->>User: Visualizza Report
    User->>Teams: (Opzionale) Chiede approfondimenti su una lacuna
    Teams->>Bot: Inoltra query di follow-up
    Bot->>LLM: Analizza contesto precedente + query
    LLM-->>Bot: Restituisce risposta di follow-up
    Bot-->>Teams: Mostra approfondimento
```

## 5. Guida all'Implementazione Tecnica
### Prerequisiti
- Licenza Microsoft Copilot Studio (o Microsoft 365 con permessi abilitati per la creazione di Bot).
- Accesso a Microsoft Teams aziendale.
- Standard aziendali di documentazione chiari (per istruire il bot).

### Step 1: Configurazione di Copilot Studio
1. Accedere al portale web di Microsoft Copilot Studio.
2. Cliccare su **Nuovo Copilot** e nominarlo `Tech Doc Reviewer`.
3. Navigare nella sezione **Generative AI** e inserire nel campo delle istruzioni (System Prompt) la bozza fornita nella Fase 1. Questo darà al bot il suo "ruolo".

### Step 2: Abilitazione Upload e Conoscenza
1. Nelle impostazioni del nodo conversazionale, assicurarsi di abilitare l'opzione che consente il **File Upload** da parte dell'utente.
2. (Opzionale) Se l'azienda ha standard documentali fissi, caricarli nella sezione "Knowledge" del Copilot, in modo che l'LLM li usi come benchmark per valutare i documenti dell'utente.

### Step 3: Integrazione Canale Teams
1. Selezionare la tab **Channels** (Canali) nel menu laterale di Copilot Studio.
2. Scegliere **Microsoft Teams** e cliccare su *Turn on Teams*.
3. Completare la procedura guidata e cliccare su **Publish**.
4. Aprire Microsoft Teams, andare nella sezione App e cercare/installare il nuovo bot appena creato per iniziare a testarlo.

## 6. Rischi e Mitigazioni
- **Rischio 1:** Esposizione di architetture o dati riservati a modelli linguistici esterni. -> **Mitigazione:** L'implementazione su Copilot Studio/Teams all'interno del tenant Microsoft aziendale garantisce la protezione Enterprise (i dati non vengono usati per il training dei modelli di fondazione).
- **Rischio 2:** Allucinazioni ("falsi positivi" su errori o mancanze nel documento). -> **Mitigazione:** Il Consultant deve mantenere un ruolo attivo (Human-in-the-loop) usando l'output come check-list da verificare, e mai come documento di contestazione automatica verso il team uscente.
