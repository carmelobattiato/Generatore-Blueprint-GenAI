# Blueprint GenAI: Efficentamento del "Provisioning Infrastrutturale"

## 1. Descrizione del Caso d'Uso
**Categoria:** Provisioning & Automation
**Titolo:** Provisioning Infrastrutturale
**Ruolo:** Cloud Engineer
**Obiettivo Originale (da CSV):** Creazione e configurazione di risorse di calcolo, storage e rete (come macchine virtuali, container, database gestiti) necessarie per ospitare un nuovo servizio, seguendo le specifiche di design stabilite.
**Obiettivo GenAI:** Automatizzare la traduzione dei requisiti di design (HLD/LLD) in script di Infrastructure as Code (IaC) pronti all'uso, validando la conformità alle policy aziendali e orchestrando il provisioning tramite un'interfaccia conversazionale su Microsoft Teams.

## 2. Fasi del Processo Efficentato

### Fase 1: Generazione Codice IaC (Terraform/Bicep)
In questa fase, il Cloud Engineer utilizza l'IA per trasformare le specifiche testuali o i diagrammi di design in codice infrastrutturale completo.
*   **Tool Principale Consigliato:** `visualstudio + copilot`
*   **Alternative:** 1. `claude-code`, 2. `OpenAI Codex`
*   **Modelli LLM Suggeriti:** `Anthropic Claude Sonnet 4.6` (ottimizzato per coding complesso)
*   **Modalità di Utilizzo:** Utilizzo di Copilot Chat all'interno di VS Code per analizzare il documento di design e generare i file `.tf` o `.bicep`.
    *   **Bozza Prompt:**
        ```text
        "Basandoti sul file design_service_alpha.md allegato, genera il codice Terraform per Azure.
        Includi: 1 VNET con 2 subnet, 1 cluster AKS (min 3 nodi), e 1 database PostgreSQL gestito.
        Usa i moduli standard definiti in 'libs/terraform-modules'.
        Assicurati che i tag siano: Environment=Prod, Owner=CloudTeam."
        ```
*   **Azione Umana Richiesta:** Revisione del codice generato e verifica dei nomi delle risorse secondo naming convention.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore (scrittura moduli e debugging iniziale)
    *   *Tempo To-Be (GenAI):* 30 minuti
    *   *Risparmio %:* 91%
    *   *Motivazione:* L'IA elimina la necessità di scrivere boilerplate e cerca automaticamente la sintassi corretta dei moduli.

### Fase 2: Validazione Compliance e Security
Il codice generato viene scansionato da un agente IA per identificare misconfiguration di sicurezza o violazioni delle policy aziendali prima del commit.
*   **Tool Principale Consigliato:** `gemini-cli`
*   **Alternative:** 1. `n8n` (con nodo Python), 2. `OpenClaw`
*   **Modelli LLM Suggeriti:** `Google Gemini 3.1 Pro`
*   **Modalità di Utilizzo:** Uno script shell che invia il file IaC a Gemini per un "Security Review" rapido.
    *   **Bozza Script (check.sh):**
        ```bash
        # Utilizzo di gemini-cli per la validazione
        cat main.tf | gemini-cli "Analizza questo codice Terraform per vulnerabilità di sicurezza (es. porte aperte, mancanza encryption). Rispondi con una tabella: Rischio | Severità | Suggerimento Fix."
        ```
*   **Azione Umana Richiesta:** Approvazione dei suggerimenti di fix proposti dall'IA.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 2 ore (review manuale incrociata con policy)
    *   *Tempo To-Be (GenAI):* 5 minuti
    *   *Risparmio %:* 96%
    *   *Motivazione:* L'IA confronta istantaneamente il codice con migliaia di pattern di sicurezza noti.

### Fase 3: Orchestrazione e Provisioning via Teams
Il Cloud Engineer avvia e monitora il deploy tramite un bot su Microsoft Teams che funge da interfaccia verso la pipeline CI/CD.
*   **Tool Principale Consigliato:** `Microsoft Teams (Chatbot UI)` tramite `n8n`
*   **Alternative:** 1. `copilot studio`
*   **Modelli LLM Suggeriti:** `Google Gemini 3.1 Pro`
*   **Modalità di Utilizzo:** Integrazione di un workflow n8n che riceve comandi da Teams, esegue `terraform plan/apply` su GitHub Actions/Azure DevOps e riporta l'output sintetizzato dal LLM.
*   **Azione Umana Richiesta:** Cliccare sul pulsante "APPROVA DEPLOY" che appare nel messaggio Teams dopo il `terraform plan`.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 1 ora (monitoraggio log pipeline e switch tra tool)
    *   *Tempo To-Be (GenAI):* 10 minuti
    *   *Risparmio %:* 83%
    *   *Motivazione:* Centralizzazione del controllo e sintesi automatica degli errori di deploy.

## 3. Descrizione del Flusso Logico
Il Cloud Engineer carica il documento di design in VS Code; Copilot genera lo scheletro IaC basandosi su moduli pre-esistenti. Successivamente, uno script `gemini-cli` valida il codice contro i rischi di sicurezza. Una volta pronti, il Cloud Engineer interagisce con un bot su **Microsoft Teams** che, orchestrato da **n8n**, triggera la pipeline di provisioning. Il bot fornisce aggiornamenti in linguaggio naturale sullo stato delle risorse create, richiedendo l'intervento umano solo per l'approvazione finale del piano di esecuzione.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
  User[Cloud Engineer] --> IDE[VS Code + Copilot]
  IDE --> Git[Repo Git / IaC Code]
  Git --> Valid[gemini-cli Security Scan]
  Valid --> n8n[n8n Orchestrator]
  n8n --> Teams[Microsoft Teams Bot]
  n8n --> CICD[CI/CD Pipeline - GH Actions/ADO]
  CICD --> Cloud[Cloud Infrastructure - Azure/AWS/GCP]
  Teams --> User
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    A[Inizio: Ricezione Design HLD/LLD] --> B[Generazione IaC con Copilot]
    B --> C{Revisione Manuale?}
    C -- No --> B
    C -- Sì --> D[Esecuzione gemini-cli Security Scan]
    D --> E{Compliance OK?}
    E -- No --> B
    E -- Sì --> F[Invio notifica 'Ready to Deploy' su Teams]
    F --> G[Approvazione Umana su Teams]
    G --> H[Trigger Pipeline Provisioning]
    H --> I[Fine: Infrastruttura Pronta]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant Eng as Cloud Engineer
    participant IDE as VS Code Copilot
    participant Bot as Teams Bot (n8n)
    participant Pipe as CI/CD Pipeline
    participant LLM as Gemini LLM

    Eng->>IDE: "Genera Terraform da HLD"
    IDE-->>Eng: Ritorna Codice IaC
    Eng->>Bot: "Esegui validazione e plan"
    Bot->>LLM: Invia codice per security check
    LLM-->>Bot: Analisi Rischi (OK)
    Bot->>Pipe: Trigger Terraform Plan
    Pipe-->>Bot: Output Plan (10 risorse da creare)
    Bot->>Eng: "Pianificazione pronta: Approvi?"
    Eng->>Bot: Clicca su "APPROVA"
    Bot->>Pipe: Trigger Terraform Apply
    Pipe-->>Eng: Notifica "Provisioning Completato"
```

## 5. Guida all'Implementazione Tecnica

### Prerequisiti
- Licenza **GitHub Copilot** attiva.
- Accesso a **Google Gemini API** (per `gemini-cli`).
- Istanza **n8n** (Self-hosted o Cloud).
- App **Microsoft Teams** configurata con Webhook o Bot Framework.

### Step 1: Configurazione VS Code per IaC
1. Installare l'estensione GitHub Copilot.
2. Creare un file `.github/copilot-instructions.md` per istruire l'IA sulle naming convention aziendali e i path dei moduli Terraform.

### Step 2: Automation con gemini-cli
1. Installare `gemini-cli` via npm o scaricare il binario.
2. Configurare la variabile d'ambiente `GEMINI_API_KEY`.
3. Creare uno script di pre-commit hook che blocchi il push se `gemini-cli` rileva severità "High".

### Step 3: Workflow n8n & Teams
1. Creare un workflow n8n con un trigger "Microsoft Teams Message".
2. Aggiungere un nodo "HTTP Request" per chiamare le API della pipeline CI/CD (es. GitHub Actions Dispatch).
3. Configurare il nodo di risposta Teams per mostrare i pulsanti "Approve" e "Reject" utilizzando le **Adaptive Cards**.

## 6. Rischi e Mitigazioni
- **Rischio: Allucinazione parametri cloud (es. SKU inesistenti)** -> **Mitigazione:** Il `terraform plan` fallirebbe comunque, fornendo un feedback immediato che l'IA può usare per auto-correggersi.
- **Rischio: Esposizione Secret nel codice IaC** -> **Mitigazione:** Utilizzo di agenti IA specializzati (Gemini) con prompt specifici per la rilevazione di hardcoded secrets e integrazione obbligatoria con Key Vault/Secret Manager.
- **Rischio: Drift infrastrutturale** -> **Mitigazione:** Il bot Teams deve essere configurato per notificare anche le differenze rilevate durante i check periodici (Terraform Drift Detection).
