# Blueprint GenAI: Efficentamento del "Analisi Errori e Root Cause"

## 1. Descrizione del Caso d'Uso
**Categoria:** Assessment & Analysis
**Titolo:** Analisi Errori e Root Cause
**Ruolo:** Problem Manager
**Obiettivo Originale (da CSV):** Indagine approfondita a seguito di incidenti gravi. Identificazione della causa radice (Root Cause Analysis) di malfunzionamenti complessi e definizione di piani di azione per evitare il ripetersi del problema nel tempo.
**Obiettivo GenAI:** Automatizzare e velocizzare l'analisi dei log e delle metriche di sistema post-incidente per identificare rapidamente la Root Cause e generare in automatico una bozza strutturata di report RCA e piano d'azione (Action Plan).

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion e Analisi dei Log
L'obiettivo di questa fase è delegare all'AI il parsing massivo dei log di sistema (applicativi, di rete, OS) per trovare correlazioni, anomalie e pattern di errore temporali legati all'incidente.
*   **Tool Principale Consigliato:** `accenture ametyst` (per garantire la privacy e la sicurezza nell'ingestion di log aziendali sensibili).
*   **Alternative:** 1. `Microsoft Teams (Chatbot UI)` (integrato con backend sicuro), 2. `OpenClaw` (per modelli on-premise in caso di dati estremamente critici).
*   **Modelli LLM Suggeriti:** *Anthropic Claude Opus 4.6* (eccellente nel ragionamento su grandi moli di testo e log strutturati) o *Google Gemini 3.1 Pro* (grazie alla sua ampia context window).
*   **Modalità di Utilizzo:** Il Problem Manager carica i file di log esportati (es. `.txt`, `.csv`, `.log`) nella chat enterprise sicura.
    *Bozza di Prompt per l'analisi:*
    ```text
    Agisci come un Senior Problem Manager. Analizza i log allegati relativi a un incidente critico avvenuto il [Data/Ora].
    Sintomi riportati dagli utenti: [Breve descrizione sintomo].
    Analizza i dati ed estrai:
    1. Una rigida timeline degli eventi anomali (identificando l'evento trigger).
    2. I codici di errore ricorrenti o fatali.
    3. Le 3 ipotesi più probabili per la Root Cause del malfunzionamento, ordinate per probabilità, motivandole tecnicamente.
    ```
*   **Azione Umana Richiesta:** Il Problem Manager *deve* analizzare le 3 ipotesi proposte dall'AI, scartare i falsi positivi e validare la Root Cause effettiva in base alla propria esperienza e alla conoscenza dell'architettura.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 4-8 ore (ricerca manuale, grep su log testuali)
    *   *Tempo To-Be (GenAI):* 30 minuti
    *   *Risparmio %:* ~90%
    *   *Motivazione:* L'AI esegue un parsing quasi istantaneo di migliaia di righe, evidenziando le anomalie temporali senza richiedere la costruzione manuale di query complesse o l'uso di script regex ad-hoc.

### Fase 2: Generazione del Report RCA e Action Plan
Una volta individuata e validata la Root Cause, l'AI viene utilizzata per redigere il documento formale finale, standardizzando il formato e proponendo un piano di mitigazione.
*   **Tool Principale Consigliato:** `accenture ametyst`
*   **Alternative:** 1. `Microsoft Teams (Chatbot UI)`
*   **Modelli LLM Suggeriti:** *Anthropic Claude Opus 4.6* o *Google Gemini 3.1 Pro*.
*   **Modalità di Utilizzo:** Continuazione della conversazione avviata nella Fase 1.
    *Bozza di Prompt per la generazione:*
    ```text
    Confermo che la Root Cause è l'ipotesi numero [X]: [Descrizione Root Cause Validata].
    Sulla base di questa conferma e della timeline estratta in precedenza, genera un report formale di Root Cause Analysis (RCA).
    Struttura il documento nei seguenti paragrafi:
    - Executive Summary
    - Timeline dell'incidente
    - Descrizione Tecnica della Root Cause
    - Action Plan Preventivo: suggerisci almeno 3 azioni a breve termine (workaround/fix rapidi) e 3 azioni a lungo termine (modifiche architetturali o di processo) per evitare il ripresentarsi del problema.
    Usa un tono formale, oggettivo e adatto al management IT.
    ```
*   **Azione Umana Richiesta:** Revisione finale del documento per garantire che l'Action Plan proposto sia fattibile in termini di budget, tempi e policy aziendali.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 2 ore (stesura, formattazione, revisione)
    *   *Tempo To-Be (GenAI):* 15 minuti
    *   *Risparmio %:* ~87%
    *   *Motivazione:* L'eliminazione del "foglio bianco" velocizza drasticamente la produzione documentale; l'esperto umano si trasforma da redattore a revisore.

## 3. Descrizione del Flusso Logico
Il flusso inizia off-platform: il Problem Manager raccoglie i log di sistema dai vari tool di monitoraggio (es. Splunk, Dynatrace, ELK) in formato grezzo. Successivamente, accede al portale sicuro (es. Accenture Amethyst) e carica i file ponendo i prompt di analisi. L'LLM processa i log, incrociando i timestamp e i codici di errore, restituendo le ipotesi di causa radice. Interviene l'umano che "pivota" la conversazione validando l'ipotesi corretta. A questo punto, l'LLM, mantenendo il contesto, produce l'output finale: un report RCA pronto per essere revisionato, esportato (es. copiato su Word o Confluence) e distribuito agli stakeholder.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    User((Problem Manager)) --> |Browser/Chat UI| Portal[Accenture Amethyst / Secure Chat UI]
    Portal --> |API Rest| LLM[LLM API - Claude/Gemini]
    Log[Sistemi di Monitoraggio / Log] --> |Export manuale file .txt/.csv| User
    Portal --> |Risposte / Report RCA| User
    LLM --> |Analisi Token / Ragionamento| LLM
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    A[Estrazione Log post-incidente] --> B[Upload Log su Piattaforma GenAI Sicura]
    B --> C[Esecuzione Prompt di Analisi Log]
    C --> D{L'AI ha individuato una Root Cause plausibile?}
    D -- No --> E[L'utente fornisce più contesto o altri log]
    E --> C
    D -- Si --> F[Validazione Umana della Root Cause]
    F --> G[Esecuzione Prompt per Generazione Action Plan]
    G --> H[L'AI genera Documento RCA]
    H --> I[Revisione Umana e Pubblicazione]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant PM as Problem Manager
    participant Chat as Secure Chat Interface
    participant AI as LLM Backend

    PM->>Chat: Upload File Log + Prompt Analisi Incident
    Chat->>AI: Invia File e Istruzioni (Context Window)
    AI-->>Chat: Restituisce Timeline e 3 Ipotesi Root Cause
    Chat-->>PM: Mostra risultati
    PM->>PM: Analizza le ipotesi (Human-in-the-loop)
    PM->>Chat: Invia conferma su Ipotesi X + Richiesta Action Plan
    Chat->>AI: Invia richiesta generazione report formale
    AI-->>Chat: Restituisce RCA Document (Markdown/Testo)
    Chat-->>PM: Mostra report completo
    PM->>PM: Copia, revisiona e condivide con Stakeholder
```

## 5. Guida all'Implementazione Tecnica
### Prerequisiti
- Accesso abilitato ad un'istanza aziendale di un Chatbot GenAI sicuro che prevenga il training sui dati immessi (es. Accenture Amethyst, Copilot for Web enterprise, ChatGPT Enterprise).
- Permessi sui sistemi target per l'esportazione manuale dei log di errore.

### Step 1: Accesso e Preparazione Dati
1. Estrai i log (possibilmente filtrati per il range temporale dell'incidente per non saturare la context window) e salvali come file di testo `.txt` o `.csv`. Assicurati che non contengano PII (Personal Identifiable Information) non necessarie.
2. Accedi all'interfaccia sicura di chat aziendale.

### Step 2: Sessione di Root Cause Analysis
1. Inizia una nuova sessione di chat. Questo garantisce che l'LLM non sia inquinato da contesti precedenti.
2. Usa la funzione "Allega File" per caricare i log estratti.
3. Incolla il **Prompt per l'analisi** (definito nella Fase 1), personalizzando la data, l'ora e i sintomi dell'incidente.
4. Premi Invio e attendi la generazione delle ipotesi.

### Step 3: Generazione Report e Follow-up
1. Una volta lette le risposte, valuta qual è la Root Cause tecnicamente sensata.
2. Nella *stessa chat* (per mantenere la memoria temporanea), usa il **Prompt per la generazione** (definito nella Fase 2).
3. Copia l'output finale generato dall'AI, incollalo nel template aziendale standard (es. su Microsoft Word) per la RCA, apporta le necessarie revisioni sull'Action Plan e distribuiscilo.

## 6. Rischi e Mitigazioni
- **Rischio Allucinazione sull'Errore:** L'AI potrebbe inventare correlazioni tra log che appartengono a flussi completamente scorrelati. 
  -> **Mitigazione:** Il passaggio di "Validazione Umana" (Fase 1) è bloccante. Nessun report viene generato senza che il Problem Manager confermi l'ipotesi proposta.
- **Rischio Data Leakage (Log Sensibili):** Caricamento di log contenenti password in chiaro, dati utente o IP sensibili in strumenti AI pubblici.
  -> **Mitigazione:** Uso tassativo di strumenti approvati dall'azienda (es. Accenture Amethyst) che operano in ambiente segregato e non utilizzano i prompt per il retraining dei modelli. Sensibilizzazione del personale allo scrubbing dei log prima dell'upload.
- **Rischio Context Window Limit:** I file di log possono superare il limite di token accettabili dall'LLM, causando errori o troncamenti nell'analisi.
  -> **Mitigazione:** Limitare l'export dei log a una finestra temporale stretta (es. +/- 15 minuti dall'incidente) o filtrare preventivamente (es. usando comandi grep locali) le righe puramente informative (livello INFO/DEBUG) tenendo solo WARN, ERROR, FATAL.