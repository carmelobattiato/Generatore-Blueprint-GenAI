# Blueprint GenAI: Efficentamento del "Analisi Performance"

## 1. Descrizione del Caso d'Uso
**Categoria:** Assessment & Analysis
**Titolo:** Analisi Performance
**Ruolo:** Performance Engineer
**Obiettivo Originale (da CSV):** Monitoraggio e valutazione delle prestazioni di sistemi e applicazioni. Include l'analisi dei log, dei consumi di risorse computazionali e di I/O per identificare trend di degrado prestazionale e proporre ottimizzazioni.
**Obiettivo GenAI:** Automatizzare l'analisi dei log di performance (CPU, RAM, I/O) e la generazione di un report di sintesi sui trend di degrado prestazionale con relative proposte di ottimizzazione.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion dei Log e Analisi Metriche
L'ingegnere carica i file di log o gli estratti CSV delle metriche prestazionali all'interno dello strumento, per permettere all'AI di correlare i dati e individuare le anomalie in tempo record.
*   **Tool Principale Consigliato:** `gemini-cli`
*   **Alternative:** 1. `accenture ametyst`, 2. `Microsoft Teams (Chatbot UI)`
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro (ideale per l'ingestion di file CSV e log di grandi dimensioni grazie all'ampia finestra di contesto).
*   **Modalità di Utilizzo:** Utilizzo di uno script Bash/CLI con `gemini-cli` per processare un file CSV contenente metriche e richiedere un'analisi strutturata dei colli di bottiglia.
    ```bash
    gemini "Analizza questo file CSV di log prestazionali e identifica i trend di degrado, i colli di bottiglia e fornisci 3 raccomandazioni di ottimizzazione. Formato output: Markdown." --file performance_logs.csv > report_ottimizzazione.md
    ```
*   **Azione Umana Richiesta:** Il Performance Engineer seleziona il periodo di tempo e il dataset da fornire all'AI, e valida tecnicamente le raccomandazioni prodotte dal modello prima di applicare le ottimizzazioni.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 4 ore (analisi manuale dei grafici, pivot e incrocio di log sparsi).
    *   *Tempo To-Be (GenAI):* 10 minuti (esecuzione comando e revisione).
    *   *Risparmio %:* 95%
    *   *Motivazione:* L'AI riesce a correlare migliaia di righe di log e metriche in pochi secondi, identificando anomalie e trend che un operatore umano scoverebbe solo dopo lunghe analisi su fogli di calcolo o dashboard frammentate.

## 3. Descrizione del Flusso Logico
Il flusso operativo inizia con il Performance Engineer che esporta i dati prestazionali (log, metriche di risorse) dai sistemi di monitoraggio aziendali (es. Prometheus, Zabbix, CloudWatch) in formato testo o CSV. Successivamente, l'utente esegue un rapido comando da terminale tramite `gemini-cli`, passando in input il dataset assieme a una richiesta di analisi dettagliata. L'LLM elabora i dati, individua le anomalie o i pattern di consumo anomalo (es. saturazione I/O disco o memory leak) e restituisce in output un report strutturato con le probabili cause scatenanti e i piani di mitigazione. L'esperto umano interviene in ultima battuta per revisionare il report e decidere l'implementazione pratica del tuning infrastrutturale.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    A[Performance Engineer] -->|Export Dati| B(CSV/Log File)
    B -->|Pass to CLI| C[gemini-cli]
    C -->|API Request| D[Google Gemini 3.1 Pro]
    D -->|Analysis Report| C
    C -->|Output su file| E[report_ottimizzazione.md]
    A -.->|Validation & Action| E
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    Start[Inizio Analisi] --> P1[Estrazione Log/Metriche da Monitoraggio]
    P1 --> P2[Esecuzione Script gemini-cli]
    P2 --> D1{L'AI rileva colli di bottiglia?}
    D1 -- Sì --> P3[Generazione Report e Soluzioni]
    D1 -- No --> P4[Report di Salute del Sistema Nominale]
    P3 --> V1[Validazione Umana]
    P4 --> V1
    V1 --> End[Applicazione Ottimizzazioni]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant PE as Performance Engineer
    participant CLI as gemini-cli
    participant LLM as Gemini 3.1 Pro
    
    PE->>CLI: gemini "Analizza log..." --file logs.csv > report.md
    CLI->>LLM: Invia System Prompt + Dataset (CSV)
    LLM-->>CLI: Ritorna Markdown con anomalie e fix
    CLI-->>PE: Scrive report su file locale
    PE->>PE: Legge il report e valida le proposte
    PE->>PE: Implementa ottimizzazioni sui sistemi
```

## 5. Guida all'Implementazione Tecnica
### Prerequisiti
- Installazione di `gemini-cli` sulla postazione del Performance Engineer.
- API Key attiva per il modello Google Gemini 3.1 Pro (configurata tramite variabili di ambiente o setup della CLI).
- Accesso in lettura ai sistemi di monitoraggio per poter eseguire l'export dei dati grezzi.

### Step 1: Export dei Dati
Accedere al pannello di amministrazione del sistema di monitoraggio (es. Grafana, vCenter, AWS CloudWatch, Datadog) ed esportare i dati relativi a CPU, RAM e I/O Disco/Rete per il periodo oggetto di analisi in formato CSV. Assicurarsi che i log o le metriche contengano i timestamp.

### Step 2: Utilizzo della CLI per l'Analisi
Aprire il terminale (Prompt dei comandi o Bash) nella cartella in cui si trova il file appena esportato. Eseguire il comando passandogli le istruzioni esatte per il task:
```bash
gemini "Agisci come un Performance Engineer Senior. Analizza il file CSV allegato sulle prestazioni del sistema. Identifica i picchi anomali, le saturazioni di I/O o memoria, e scrivi un report dettagliato con le root cause più probabili e un piano d'azione in 3 step per l'ottimizzazione del carico." --file extract_metrics_q1.csv > report_performance.md
```

### Step 3: Revisione e Azione (Human-in-the-loop)
Aprire il file `report_performance.md` generato, leggerne attentamente il contenuto e verificare che i colli di bottiglia evidenziati dall'AI abbiano senso nel contesto architetturale specifico (es. distinguere un picco malevolo da un normale job notturno). Pianificare gli interventi infrastrutturali (aumento risorse, ottimizzazione storage, bilanciamento del carico) basandosi sulle indicazioni validate.

## 6. Rischi e Mitigazioni
- **Rischio Allucinazioni e Falsi Positivi:** L'AI potrebbe interpretare un normale picco di carico stagionale o un job batch notturno programmato come un'anomalia. -> **Mitigazione:** Il prompt deve sempre essere arricchito con contesto operativo (es. "ignora i picchi tra le 02:00 e le 04:00"), e le conclusioni devono obbligatoriamente essere validate dall'esperto umano.
- **Esposizione di Dati Sensibili:** I file di log potrebbero contenere accidentalmente PII, query in chiaro o credenziali. -> **Mitigazione:** Prediligere sempre l'export di metriche prettamente numeriche (es. contatori CPU/RAM) oppure sanitizzare/anonimizzare i log prima dell'invio all'LLM. Se si usano log integrali sensibili, optare per soluzioni come OpenClaw o tool aziendali sicuri (es. Accenture Amethyst).
