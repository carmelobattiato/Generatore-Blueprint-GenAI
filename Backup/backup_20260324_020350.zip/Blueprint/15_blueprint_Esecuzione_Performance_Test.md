# Blueprint GenAI: Efficentamento dell'"Esecuzione Performance Test"

## 1. Descrizione del Caso d'Uso
**Categoria:** Testing & QA
**Titolo:** Esecuzione Performance Test
**Ruolo:** Performance Tester
**Obiettivo Originale (da CSV):** Realizzazione di test di carico (Load, Stress, Endurance) utilizzando strumenti di simulazione del traffico. Misurazione dei tempi di risposta e del comportamento dei sistemi sotto sforzo massimo per certificare la capacità prima della messa in produzione.
**Obiettivo GenAI:** Automatizzare e accelerare drasticamente la scrittura degli script per la simulazione del traffico (es. k6, JMeter) e l'analisi critica dei log e dei risultati generati dai test, per identificare immediatamente colli di bottiglia e degradi prestazionali.

## 2. Fasi del Processo Efficentato

### Fase 1: Generazione Rapida Script di Carico (Load/Stress)
L'AI viene utilizzata per generare istantaneamente script di test configurati secondo i parametri desiderati (es. numero di Virtual Users, durata, endpoint, assertion) utilizzando linguaggi standard come JavaScript per k6 o file XML per JMeter.
*   **Tool Principale Consigliato:** `gemini-cli` (per automazione e scripting rapido da terminale)
*   **Alternative:** 1. visualstudio + copilot, 2. claude-code
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro o OpenAI GPT-5.4
*   **Modalità di Utilizzo:** Il tester fornisce una descrizione in linguaggio naturale dei parametri di test tramite CLI e salva direttamente l'output.
    ```bash
    gemini-cli "Scrivi uno script k6 per un Load Test con ramp-up a 200 VUs in 30s, mantenimento per 3 minuti e ramp-down in 30s. L'endpoint è https://api.sistema.local/v1/auth. Aggiungi assertion per http_req_duration < 250ms e success rate > 99%. Restituisci SOLO il codice javascript." > load_test.js
    ```
*   **Azione Umana Richiesta:** Il tester deve eseguire una rapida ispezione visiva del codice generato, sostituire eventuali token/credenziali placeholder, ed eseguire lo script (es. `k6 run load_test.js --out json=results.json`).
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 2 ore
    *   *Tempo To-Be (GenAI):* 5 minuti
    *   *Risparmio %:* 95%
    *   *Motivazione:* L'AI elimina la necessità di scrivere boilerplate code, configurare manualmente le fasi di rampa e definire le assertion riga per riga, permettendo al tester di concentrarsi solo sulle metriche.

### Fase 2: Analisi Intelligente dei Risultati e Identificazione Colli di Bottiglia
Invece di analizzare manualmente enormi dashboard o file JSON/CSV contenenti migliaia di righe di metriche aggregate, i risultati grezzi vengono passati in pasto all'AI che evidenzia anomalie, latenze eccessive e suggerisce cause infrastrutturali probabili.
*   **Tool Principale Consigliato:** `gemini-cli`
*   **Alternative:** 1. Accenture Amethyst (per dati altamente sensibili/on-premise), 2. ChatGPT Agent
*   **Modelli LLM Suggeriti:** Anthropic Claude Sonnet 4.6 o Google Gemini 3.1 Pro (eccellenti per l'analisi di file log e JSON strutturati)
*   **Modalità di Utilizzo:** Piping del risultato del test direttamente nell'AI.
    ```bash
    cat results.json | gemini-cli "Agisci come un Performance Engineer Senior. Analizza questi risultati del load test. 1) Evidenzia le metriche critiche (error rate, p90, p95, p99). 2) Identifica il potenziale collo di bottiglia. 3) Suggerisci 3 azioni di tuning sistemistico (DB, Network, RAM/CPU) per migliorare i tempi di risposta. Usa il formato Markdown." > report_performance.md
    ```
*   **Azione Umana Richiesta:** Il Performance Tester e l'Architetto validano i suggerimenti di tuning dell'AI e decidono quali implementare prima della messa in produzione.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 3 ore
    *   *Tempo To-Be (GenAI):* 10 minuti
    *   *Risparmio %:* 94%
    *   *Motivazione:* La correlazione dei dati e l'estrazione delle statistiche sui percentili (p95, p99) avviene in secondi. L'AI fornisce non solo i numeri, ma un'immediata correlazione logica sulle cause delle latenze.

## 3. Descrizione del Flusso Logico
Il flusso è strettamente operativo e basato su riga di comando per la massima velocità. Il Performance Tester avvia il processo chiedendo a `gemini-cli` di tradurre i requisiti di business (es. "simulare 1000 utenti") in un vero e proprio script di test (es. in k6). Una volta generato, l'umano lo ispeziona rapidamente e lancia l'esecuzione sul sistema di test. Al termine dell'esecuzione sotto sforzo massimo, il tool di test salva i risultati in un file JSON o testo. Questo file viene re-inviato a `gemini-cli` tramite una direttiva di shell (`cat file | gemini-cli...`) che analizza istantaneamente lo stress a cui è stato sottoposto il sistema, redigendo un report diagnostico in Markdown pronto per essere discusso dal team architetturale.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    A[Performance Tester] -->|CLI Commands| B[Gemini CLI]
    B -->|API LLM| C[LLM: Gemini 3.1 Pro / Claude 4.6]
    C -->|Generate Code| D[load_test.js script]
    A -->|k6 run| D
    D -->|HTTP/TCP Load| E[Target Infrastructure / System under test]
    E -->|Metrics / Latencies| D
    D -->|Export| F[results.json]
    A -->|cat results \| gemini-cli| B
    B -->|API LLM Analytics| C
    C -->|Insights| G[report_performance.md]
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    Start[Inizio Attività] --> Prompt[Generazione Script via Gemini CLI]
    Prompt --> Review{Script OK?}
    Review -- No --> Refine[Modifica Prompt / Rigenerazione]
    Refine --> Review
    Review -- Si --> Execute[Esecuzione Test k6/JMeter su Sistema Target]
    Execute --> Export[Salvataggio risultati grezzi]
    Export --> Analisi[Piping risultati in Gemini CLI per analisi]
    Analisi --> Eval{Anomalie Trovate?}
    Eval -- Si --> Tuning[Implementazione tuning e ripetizione Test]
    Tuning --> Execute
    Eval -- No --> Cert[Certificazione Capacità e Messa in Produzione]
    Cert --> Fine[Fine Attività]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant Tester as Performance Tester
    participant CLI as Gemini CLI
    participant LLM as LLM Backend
    participant System as Target System
    
    Tester->>CLI: Richiesta: Genera script di Load Test
    CLI->>LLM: Passaggio prompt + requisiti
    LLM-->>CLI: Codice sorgente k6
    CLI-->>Tester: Salvataggio load_test.js
    Tester->>System: k6 run load_test.js (Inizio Carico)
    System-->>Tester: Risposte HTTP, latenze, errori
    Tester->>Tester: Esportazione in results.json
    Tester->>CLI: cat results.json | Richiesta analisi
    CLI->>LLM: Log + Richiesta identificazione colli di bottiglia
    LLM-->>CLI: Report strutturato (P95, Error rate, Tuning)
    CLI-->>Tester: report_performance.md
    Tester->>Tester: Validazione azioni di tuning e chiusura task
```

## 5. Guida all'Implementazione Tecnica

### Prerequisiti
- Accesso a riga di comando (Terminale) sulla macchina del Performance Tester.
- Installazione di `gemini-cli` e configurazione con API Key valida (Google AI Studio o Anthropic).
- Installazione locale di un engine di load testing (si consiglia fortemente `k6` di Grafana Labs per la sua semplicità e output JSON/CLI).

### Step 1: Installazione e Configurazione Tooling
1. Verificare l'installazione di k6: `brew install k6` (macOS) o equivalente Linux/Windows.
2. Assicurarsi che `gemini-cli` sia configurato con il modello desiderato come default:
   `gemini-cli config set model "gemini-3.1-pro"`

### Step 2: Generazione ed Esecuzione del Test
1. Aprire il terminale e lanciare la generazione dello script passando come argomento i KPI previsti.
2. Salvare l'output direttamente su file usando l'operatore bash `>`.
3. Eseguire il load test generando un output JSON facilmente parsabile dall'AI:
   `k6 run load_test.js --summary-export=results.json`

### Step 3: Generazione del Report di Performance
1. Al termine del test, utilizzare il comando pipe per far analizzare i dati grezzi all'AI.
2. Esempio:
   `cat results.json | gemini-cli "Analizza questi risultati. Il sistema è pronto per la produzione se il p95 è sotto i 300ms. Evidenzia i parametri non rispettati." > esito_test.md`
3. Il file `esito_test.md` può essere ora condiviso o allegato al ticket Jira della release.

## 6. Rischi e Mitigazioni
- **Rischio 1:** Esposizione di URL sensibili, token di autenticazione o credenziali nel prompt inviato all'LLM. -> **Mitigazione:** Istruire l'utente a richiedere script con placeholder (es. `<INSERT_TOKEN_HERE>`) e inserirli manualmente o via variabili d'ambiente in locale prima dell'esecuzione.
- **Rischio 2:** L'AI propone configurazioni di test errate (es. attacco DDoS involontario generando troppi Virtual Users per le capacità della rete locale). -> **Mitigazione:** Il tester umano DEVE validare i parametri numerici di rampe e VUs (Virtual Users) nello script generato prima di lanciare il comando di esecuzione `run`.
- **Rischio 3:** Limiti di token (Token Limits) nel piping di risultati enormi. -> **Mitigazione:** Istruire k6 a generare JSON di "summary" aggregati invece di JSON con singole righe di richiesta, in modo da mantenere l'input sotto i limiti del context window dell'LLM (es. usare `--summary-export` anziché loggare ogni singola request).