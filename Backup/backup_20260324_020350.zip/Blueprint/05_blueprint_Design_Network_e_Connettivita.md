# Blueprint GenAI: Efficentamento del "Design Network e Connettività"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design
**Titolo:** Design Network e Connettività
**Ruolo:** Network Architect
**Obiettivo Originale (da CSV):** Progettazione dell'infrastruttura di rete logica e fisica. Include la definizione di topologie di rete, VPN, connessioni dedicate verso provider esterni, firewalling di perimetro e segmentazione interna.
**Obiettivo GenAI:** Automatizzare la generazione del documento di High-Level Design (HLD) di rete, la pianificazione degli indirizzamenti IP e la definizione delle matrici di segmentazione/firewalling partendo da requisiti di business espressi in linguaggio naturale.

## 2. Fasi del Processo Efficentato

### Fase 1: Raccolta Requisiti Interattiva (Discovery)
L'architetto interagisce con un bot su Microsoft Teams per fornire i parametri chiave: numero di sedi, range IP aziendali, necessità di interconnessione (Cloud/On-Prem), livelli di sicurezza e zone di trust.
*   **Tool Principale Consigliato:** Microsoft Teams (Chatbot UI) + Copilot Studio
*   **Alternative:** 1. Accenture Amethyst, 2. ChatGPT Agent
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4 (per l'eccellente capacità di conversazione strutturata e estrazione entità)
*   **Modalità di Utilizzo:** Configurazione di un "Network Design Agent" che guida l'utente attraverso una checklist dinamica, salvando i dati in una struttura JSON/Markdown pronta per la fase successiva.
    *   **Bozza System Prompt:**
        ```markdown
        Sei un Network Architect AI Senior. Il tuo compito è intervistare l'utente per raccogliere i dati necessari a un design di rete. 
        Chiedi specificamente:
        1. Quali provider (AWS, Azure, GCP, On-Prem) sono coinvolti?
        2. Qual è il range IP master (CIDR)?
        3. Quante VPC/VNET e subnet sono necessarie?
        4. Tipologia di VPN (S2S, Client-to-Site) o connessioni dedicate (ExpressRoute/DirectConnect)?
        5. Requisiti di segmentazione (DMZ, Internal, Database zone).
        Fornisci un riepilogo strutturato alla fine.
        ```
*   **Azione Umana Richiesta:** Validazione del riepilogo dei requisiti generato dal bot.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 4 ore (meeting, mail, note sparse)
    *   *Tempo To-Be (GenAI):* 15 minuti
    *   *Risparmio %:* 94%
    *   *Motivazione:* Eliminazione di iterazioni via mail e standardizzazione immediata dei requisiti.

### Fase 2: Generazione HLD e Diagrammi Topologici
Generazione automatica della documentazione tecnica, inclusi i piani di indirizzamento IP (IP Plan) e il codice Mermaid.js per i diagrammi di rete.
*   **Tool Principale Consigliato:** Accenture Amethyst (per la sicurezza del dato e generazione documenti)
*   **Alternative:** 1. gemini-cli (per automazione bulk), 2. VisualStudio + Copilot (per script di rete)
*   **Modelli LLM Suggeriti:** Anthropic Claude Sonnet 4.6 (superiore nella precisione tecnica e generazione di diagrammi strutturati)
*   **Modalità di Utilizzo:** Invio del JSON dei requisiti a un prompt specializzato che restituisce un file Markdown completo di tabelle IP e codice `mermaid`.
    *   **Bozza Prompt Tecnico:**
        ```text
        Analizza i requisiti di rete forniti: [INPUT_JSON]. 
        Genera un High-Level Design (HLD) che includa:
        1. Tabella Subnetting (Subnet Name, CIDR, Gateway, VLAN ID).
        2. Configurazione logica delle VPN e regole di routing statico/BGP.
        3. Diagramma di rete in formato Mermaid.js (graph TD).
        Usa standard industriali (Hub & Spoke architecture se Cloud).
        ```
*   **Azione Umana Richiesta:** Revisione critica della topologia proposta e verifica assenza di sovrapposizioni IP.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 8 ore (scrittura doc e disegno Visio)
    *   *Tempo To-Be (GenAI):* 30 minuti
    *   *Risparmio %:* 93%
    *   *Motivazione:* La generazione istantanea di diagrammi e tabelle IP abbatte i tempi di editing manuale.

### Fase 3: Mapping Regole di Firewalling e Segmentazione
Definizione delle zone di sicurezza e delle policy di accesso (Source/Destination Matrix) basate sulla segmentazione logica definita.
*   **Tool Principale Consigliato:** gemini-cli
*   **Alternative:** 1. ChatGPT Agent, 2. OpenClaw (per dati ultra-sensibili)
*   **Modelli LLM Suggeriti:** Google Gemini 3 Deep Think (ideale per logica complessa e cross-referencing di policy)
*   **Modalità di Utilizzo:** Fornire l'elenco dei servizi e server; l'AI genera la matrice di firewalling e suggerisce le regole di "Default Deny".
    *   **Bozza Script Python di supporto (minimale):**
        ```python
        import os
        from gemini_api import GeminiModel # Esempio concettuale

        def generate_firewall_rules(design_doc):
            prompt = f"Basandoti su questo HLD: {design_doc}, genera una tabella CSV delle regole firewall: Source, Dest, Port, Protocol, Action, Reason."
            return GeminiModel.generate(prompt)
        ```
*   **Azione Umana Richiesta:** Approvazione formale della Security Matrix prima dell'eventuale implementazione IaC.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore (analisi flussi applicativi)
    *   *Tempo To-Be (GenAI):* 20 minuti
    *   *Risparmio %:* 94%
    *   *Motivazione:* L'AI identifica automaticamente le dipendenze standard (es. DNS, NTP, Active Directory) riducendo le dimenticanze.

## 3. Descrizione del Flusso Logico
Il processo inizia con l'input dell'architetto su **Microsoft Teams**, dove un bot di **Copilot Studio** estrae i requisiti tecnici. Questi dati fluiscono in **Accenture Amethyst** dove l'LLM (**Claude 4.6**) redige l'HLD e i diagrammi. Infine, le specifiche di connettività passano a **Gemini 3 Deep Think** che elabora la matrice di sicurezza granulare. L'intero output viene consolidato in un unico repository Git o SharePoint per la revisione finale umana.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
  User((Network Architect)) -->|Input Requisiti| Teams[Microsoft Teams Bot]
  Teams -->|Orchestrazione| CS[Copilot Studio]
  CS -->|Prompting| LLM_API{GenAI Gateway}
  LLM_API -->|Engine 1: GPT-5.4| Discovery[Analisi Requisiti]
  LLM_API -->|Engine 2: Claude 4.6| HLD[Generazione HLD & Mermaid]
  LLM_API -->|Engine 3: Gemini 3| Sec[Matrice Firewalling]
  HLD -->|Output| MD[Documento HLD .md]
  Sec -->|Output| CSV[Firewall Rules .csv]
  MD & CSV --> Review{Human Validation}
```

### 4.2 Process Diagram
```mermaid
flowchart TD
  A[Inizio: Richiesta Design Rete] --> B[Intervista via Teams Bot]
  B --> C{Dati Completi?}
  C -- No --> B
  C -- Si --> D[Generazione HLD & IP Plan via AI]
  D --> E[Generazione Diagramma Mermaid]
  E --> F[Definizione Regole Firewall]
  F --> G[Revisione Esperto Network]
  G --> H{Approvato?}
  H -- No --> D
  H -- Si --> I[Pubblicazione Blueprint Finale]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
  participant Architect as Network Architect
  participant Bot as Teams/Copilot Bot
  participant AI as LLM (Claude/Gemini)
  
  Architect->>Bot: Invia parametri (VPC, CIDR, VPN)
  Bot->>AI: Analizza requisiti e genera struttura
  AI-->>Bot: JSON strutturato dei requisiti
  Bot->>AI: Genera HLD e Diagramma Mermaid
  AI-->>Bot: Documento Markdown + Codice Mermaid
  Bot->>Architect: Mostra bozza HLD per approvazione
  Architect->>Bot: Approva e richiedi regole Firewall
  Bot->>AI: Genera Security Matrix
  AI-->>Bot: Tabella Regole (CSV)
  Bot->>Architect: Consegna pacchetto design completo
```

## 5. Guida all'Implementazione Tecnica

### Prerequisiti
- Licenza Microsoft Copilot Studio.
- Accesso ad Accenture Amethyst o API Gateway aziendale per LLM (OpenAI/Anthropic/Google).
- Plugin Mermaid.js abilitato nel visualizzatore Markdown (es. VS Code o GitHub).

### Step 1: Configurazione Copilot Studio su Teams
1. Accedi a [Copilot Studio](https://copilotstudio.microsoft.com/).
2. Crea un nuovo "Copilot" denominato "Network Design Assistant".
3. Configura i "Topics" per gestire la conversazione guidata (Discovery).
4. Inserisci il **System Prompt** fornito nella Fase 1 per istruire il bot sul suo ruolo.
5. Pubblica il bot nel canale Teams del team "Network & Security".

### Step 2: Automazione Documentazione con Accenture Amethyst
1. Crea un template di prompt in Amethyst che accetti il JSON dal bot.
2. Configura l'output in formato Markdown.
3. Utilizza la funzione di "Web Search" integrata per verificare i limiti correnti dei provider cloud (es. limiti di quote VPC su Azure/AWS) e arricchire il design.

### Step 3: Visualizzazione Diagrammi
1. Copia il codice `mermaid` generato dall'AI.
2. Incollalo in un file `.md` o usa un editor online (Mermaid Live Editor) per generare il PDF/PNG della topologia di rete da allegare al verbale di progetto.

## 6. Rischi e Mitigazioni
- **Rischio 1: Overlapping IP (Sovrapposizione range):** L'AI potrebbe proporre range già in uso se non istruita correttamente. -> **Mitigazione:** Integrare nel prompt l'elenco degli IP già assegnati (Export dal CMDB/IPAM aziendale).
- **Rischio 2: Allucinazioni su porte firewall:** Suggerimento di porte errate per protocolli legacy. -> **Mitigazione:** Validazione obbligatoria (Human-in-the-loop) da parte del Network Architect senior.
- **Rischio 3: Privacy dei dati di rete:** Esposizione della topologia aziendale su LLM pubblici. -> **Mitigazione:** Utilizzo esclusivo di modelli Enterprise (Accenture Amethyst o OpenClaw on-prem) che garantiscono il non-addestramento sui dati inseriti.
