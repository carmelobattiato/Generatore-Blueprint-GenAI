# Blueprint GenAI: Efficentamento della "Scrittura Test Non Funzionali"

## 1. Descrizione del Caso d'Uso
**Categoria:** Testing & QA
**Titolo:** Scrittura Test Non Funzionali
**Ruolo:** QA Infrastructure Specialist
**Obiettivo Originale (da CSV):** Progettazione e stesura dei casi di test relativi ad aspetti non funzionali dell'infrastruttura, quali scalabilità, affidabilità, sicurezza, failover e ripristino. Definizione delle metriche di successo e dei criteri di accettazione.
**Obiettivo GenAI:** Automatizzare la generazione rapida e strutturata dei casi di test non funzionali (NFR - Non-Functional Requirements), definendo per ciascuno scenari, metriche di successo e criteri di accettazione, basandosi sulla documentazione architetturale fornita.

## 2. Fasi del Processo Efficentato

### Fase 1: Generazione Automatica dei Casi di Test Non Funzionali
L'Infrastracture QA Specialist fornisce in input al chatbot su Microsoft Teams il documento architetturale (HLD/LLD) o una breve descrizione dell'infrastruttura target. L'AI genera istantaneamente una tabella con i test case per scalabilità, affidabilità, failover e sicurezza, includendo metriche e criteri di accettazione.
*   **Tool Principale Consigliato:** Copilot Studio (per creazione bot e pubblicazione su Microsoft Teams)
*   **Alternative:** 1. Accenture Amethyst, 2. ChatGPT Agent
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro o OpenAI GPT-5.4
*   **Modalità di Utilizzo:** Configurazione di un chatbot su Microsoft Teams che accetta file (es. PDF dell'architettura) e genera i casi di test.
    **Bozza del System Prompt del Bot:**
    ```text
    Sei un QA Infrastructure Specialist esperto. Il tuo compito è analizzare la descrizione o il documento architetturale fornito dall'utente e generare un elenco dettagliato di Test Non Funzionali (Scalabilità, Affidabilità, Sicurezza, Failover, Ripristino). 
    Restituisci l'output in formato tabellare Markdown con le seguenti colonne:
    | ID Test | Categoria | Descrizione Scenario | Metriche di Successo | Criteri di Accettazione (SLA/RTO/RPO) |
    Assicurati che i test siano specifici per le tecnologie menzionate nel documento.
    ```
*   **Azione Umana Richiesta:** Il QA Specialist deve revisionare i test proposti, perfezionare le metriche di successo in base ai veri SLA contrattuali e validare il documento finale.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore
    *   *Tempo To-Be (GenAI):* 30 minuti
    *   *Risparmio %:* 91%
    *   *Motivazione:* L'AI elimina il "foglio bianco" strutturando immediatamente i test case e deducendo le metriche standard dalle best practice di settore; l'umano interviene solo per la fine-tuning dei parametri.

## 3. Descrizione del Flusso Logico
Il QA Infrastructure Specialist accede al canale Microsoft Teams dedicato al Testing e interagisce con il Bot QA (sviluppato tramite Copilot Studio). L'utente carica l'High Level Design (HLD) dell'infrastruttura o descrive testualmente l'ambiente. Il Bot elabora il contesto tramite LLM e restituisce una tabella strutturata contenente tutti i test non funzionali necessari (failover, sicurezza, performance, ecc.) con i relativi criteri di accettazione. Il QA Specialist copia l'output, lo revisiona integrando i valori esatti di SLA richiesti dal cliente e lo esporta nel tool di Test Management aziendale.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    A[QA Infrastructure Specialist] -->|Interagisce tramite chat e upload| B[Microsoft Teams UI]
    B -->|Invia dati e documenti| C[Copilot Studio Bot]
    C -->|API Request con System Prompt| D[LLM - Gemini 3.1 Pro / GPT-5.4]
    D -->|Restituisce Tabella Test| C
    C -->|Mostra output formattato| B
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    A[Inizio: Necessità di Test Non Funzionali] --> B[Upload Documentazione Architetturale sul Bot Teams]
    B --> C{L'AI ha contesto sufficiente?}
    C -->|No| D[L'AI chiede chiarimenti su tecnologie o SLA]
    D --> B
    C -->|Sì| E[Generazione Tabella Casi di Test NFR]
    E --> F[Revisione del QA Specialist]
    F --> G{Le metriche sono allineate ai contratti?}
    G -->|No| H[Aggiustamento manuale dei criteri di accettazione]
    H --> I
    G -->|Sì| I[Approvazione e import nel Test Management Tool]
    I --> J[Fine Processo]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant U as QA Specialist
    participant T as MS Teams (Bot UI)
    participant CS as Copilot Studio
    participant LLM as API LLM
    
    U->>T: Upload HLD.pdf e richiesta test NFR
    T->>CS: Inoltro payload (File + User Query)
    CS->>LLM: Prompt elaborato (System Prompt QA + Contenuto File)
    LLM-->>CS: Tabella Markdown con Test Cases e Metriche
    CS-->>T: Risposta formattata
    T-->>U: Mostra Tabella Test Non Funzionali
    U->>U: Revisione e validazione SLA
    U->>U: Esportazione documento finale
```

## 5. Guida all'Implementazione Tecnica
### Prerequisiti
- Licenza Microsoft Copilot Studio (o Microsoft Power Virtual Agents).
- Abilitazione all'installazione di app personalizzate su Microsoft Teams.
- Accesso a un LLM Enterprise (Azure OpenAI GPT-5.4 o Google Gemini 3.1 Pro via API).

### Step 1: Configurazione di Copilot Studio
1. Accedere al portale di Microsoft Copilot Studio.
2. Cliccare su "Nuovo Copilot" e assegnare il nome "QA NFR Generator".
3. Nella sezione "Generative AI", impostare le istruzioni base (System Prompt) utilizzando la bozza fornita nella Fase 1.
4. Abilitare la funzionalità di "File Upload" nei nodi di conversazione per permettere all'utente di caricare documenti PDF/Word.

### Step 2: Integrazione Canale Teams
1. Nel menu laterale di Copilot Studio, andare su "Channels" (Canali) e selezionare "Microsoft Teams".
2. Cliccare su "Turn on Teams" e completare l'associazione.
3. Scaricare il pacchetto dell'app (file `.zip` del manifest).
4. Accedere a Microsoft Teams, andare su "App" > "Gestisci le tue app" > "Carica un'app personalizzata" e importare il file `.zip`.

### Step 3: Test e Rilascio
1. Aprire la chat con "QA NFR Generator" su Teams.
2. Caricare un documento di test e scrivere: "Genera i test di failover e sicurezza per questa architettura".
3. Verificare che l'output sia formattato correttamente in tabella Markdown.

## 6. Rischi e Mitigazioni
- **Rischio 1:** **Metriche di default irrealistiche:** L'AI potrebbe proporre SLA (es. 99.999%) o RTO troppo stringenti e non supportati dalla reale architettura. -> **Mitigazione:** Istruire l'AI tramite prompt a proporre range (es. 99.9% - 99.99%) e rendere obbligatorio il passaggio di validazione umana per fissare il valore esatto contrattuale.
- **Rischio 2:** **Condivisione di documenti sensibili del cliente:** Caricare documenti architetturali (HLD/LLD) sul bot potrebbe esporre dati confidenziali se il tenant non è protetto. -> **Mitigazione:** Assicurarsi che il bot in Copilot Studio utilizzi instanze LLM aziendali (Zero Data Retention) e vietare l'uso di chatbot pubblici.