# Blueprint GenAI: Efficentamento del "Design Backup e Retention"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design
**Titolo:** Design Backup e Retention
**Ruolo:** Storage & Backup Architect
**Obiettivo Originale (da CSV):** Progettazione delle politiche di salvataggio dei dati aziendali. Include la definizione della frequenza di backup (giornalieri, settimanali, mensili), della tipologia (completi, incrementali) e del periodo di conservazione per garantire la conformità normativa.
**Obiettivo GenAI:** Automatizzare la generazione di un documento di policy di Backup e Retention ottimizzato per specifici workload e requisiti normativi (es. GDPR, HIPAA), definendo frequenze, tipologie (full/incremental) e retention period, riducendo i tempi di stesura manuale.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion Requisiti e Generazione Policy
L'architetto inserisce i parametri del workload (tipo di dato, criticità, SLA, RTO/RPO richiesti e framework normativo) tramite un form/chat su Microsoft Teams. L'AI analizza i requisiti e genera una bozza strutturata della policy di Backup e Retention.
*   **Tool Principale Consigliato:** Copilot Studio (su Microsoft Teams)
*   **Alternative:** 1. Accenture Amethyst, 2. AI-Studio Google (per generazione WebApp/Dashboard)
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro o OpenAI GPT-5.4
*   **Modalità di Utilizzo:** Configurazione di un chatbot in Microsoft Teams. L'utente interagisce con il bot fornendo i dettagli strutturati o in linguaggio naturale.
    Bozza di System Prompt per il bot:
    ```markdown
    Sei un "Storage & Backup Architect Assistant". Il tuo obiettivo è generare una policy di Backup e Retention aziendale.
    Riceverai in input: 
    - Tipo di workload (es. Database Transazionale, File Server)
    - Requisiti di Compliance (es. GDPR, ISO 27001)
    - RPO e RTO desiderati
    
    Genera un documento in formato Markdown che includa:
    1. Frequenza di backup (giornalieri, settimanali, ecc.)
    2. Tipologia (Full, Incremental, Differential)
    3. Periodo di Retention (Short-term e Long-term)
    4. Motivazione delle scelte basata sui requisiti normativi forniti.
    ```
*   **Azione Umana Richiesta:** L'architetto deve validare le frequenze, i periodi di conservazione e l'aderenza alle normative prima dell'approvazione finale del documento.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 4 ore
    *   *Tempo To-Be (GenAI):* 20 minuti
    *   *Risparmio %:* 91%
    *   *Motivazione:* L'AI applica istantaneamente le best practice e i vincoli normativi standard al workload specifico, eliminando la necessità di redigere il documento da zero e consultare manualmente le linee guida di compliance per ogni tipologia di dato.

## 3. Descrizione del Flusso Logico
Il flusso inizia all'interno di Microsoft Teams, dove lo Storage & Backup Architect interagisce con il bot basato su Copilot Studio. L'utente fornisce i requisiti chiave (tipo di dati, SLA, RTO/RPO e normative di riferimento). Il bot invia il payload al modello LLM (es. GPT-5.4 o Gemini 3.1 Pro), che elabora le informazioni e restituisce una policy di backup dettagliata e strutturata. Il documento viene presentato nella chat per la revisione. L'architetto esamina la policy, apporta eventuali correzioni tramite prompt successivi ("aggiungi un retention off-site annuale") e, una volta soddisfatto, approva la policy finale per la successiva implementazione tecnica (es. configurazione dei software di backup enterprise).

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    A[Storage & Backup Architect] -->|Interagisce tramite chat| B[Microsoft Teams UI]
    B -->|Invia requisiti workload| C[Copilot Studio / Bot Backend]
    C -->|API Request| D[LLM - es. Gemini 3.1 Pro / GPT-5.4]
    D -->|Genera Policy strutturata| C
    C -->|Risposta Markdown| B
    B -->|Approvazione e Export| E[Document Repository / Wiki]
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    Start[Avvio Richiesta] --> Input[Inserimento parametri workload e compliance in Teams]
    Input --> GenAI[L'LLM genera la policy di Backup e Retention]
    GenAI --> Review{Validazione Architetto}
    Review -->|Richiede Modifiche| Refine[Aggiunta dettagli via prompt]
    Refine --> GenAI
    Review -->|Approvato| Export[Esportazione Policy Definitiva]
    Export --> End[Fine Processo]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant Arch as Storage & Backup Architect
    participant Teams as Microsoft Teams
    participant LLM as LLM API (GenAI)
    
    Arch->>Teams: Fornisce dati workload, RTO/RPO e normative
    Teams->>LLM: Invia prompt con contesto e requisiti
    LLM-->>Teams: Restituisce policy di Backup & Retention
    Teams-->>Arch: Mostra la policy generata in Markdown
    alt Richiesta modifiche
        Arch->>Teams: Prompt correttivo (es. "Aumenta retention mensile")
        Teams->>LLM: Invia nuovo prompt di affinamento
        LLM-->>Teams: Policy aggiornata
        Teams-->>Arch: Mostra nuova versione
    end
    Arch->>Teams: Approva il documento
```

## 5. Guida all'Implementazione Tecnica
### Prerequisiti
- Licenza Microsoft Copilot Studio (o equivalente framework bot aziendale).
- Accesso a Microsoft Teams come amministratore/sviluppatore per la pubblicazione del bot.
- API Key o integrazione Enterprise per un modello LLM avanzato (es. OpenAI via Azure o Google Cloud Vertex AI).

### Step 1: Creazione del Bot in Copilot Studio
1. Accedere a [Microsoft Copilot Studio](https://copilotstudio.microsoft.com/).
2. Creare un nuovo Copilot denominato "Storage Policy Generator".
3. Definire gli argomenti (Topics) principali, configurando un trigger per frasi come "Crea policy di backup" o "Nuova retention policy".

### Step 2: Configurazione del Prompt e dell'Integrazione LLM
1. Nel flusso del Topic, aggiungere nodi "Domanda" per raccogliere i parametri (Workload, RTO, RPO, Normative) e salvarli in variabili di contesto testuali.
2. Aggiungere un nodo di tipo "Azione" per chiamare il connettore GenAI (es. chiamata HTTP verso API LLM, o integrazione nativa se disponibile).
3. Inserire nel System Prompt del nodo AI il testo fornito nella "Fase 1", facendo riferimento dinamico alle variabili precedentemente raccolte per comporre la richiesta esatta.

### Step 3: Pubblicazione su Microsoft Teams
1. Testare il bot nella console integrata di Copilot Studio per verificare la corretta generazione del testo in Markdown formattato.
2. Spostarsi nella sezione "Canali" (Channels) di Copilot Studio e selezionare "Microsoft Teams".
3. Seguire la procedura guidata per abilitare il bot e inviarlo per l'approvazione (o pubblicarlo direttamente).
4. Condividere il bot con i colleghi del team Storage & Backup tramite l'app store interno di Teams o link diretto.

## 6. Rischi e Mitigazioni
- **Rischio 1:** Inesattezze nell'interpretazione di normative complesse (es. GDPR per dati sensibili) che portano a periodi di retention non conformi (troppo brevi o troppo lunghi). -> **Mitigazione:** "Human-in-the-loop" obbligatorio. L'architetto e il dipartimento Compliance devono validare sempre le retention proposte dall'AI per la validità legale.
- **Rischio 2:** Allucinazioni tecniche nella scelta delle tipologie di backup (es. proporre backup differenziali continui su architetture storage incompatibili). -> **Mitigazione:** Istruire l'LLM tramite il System Prompt ad attenersi rigidamente agli standard tecnologici in uso nell'azienda, magari fornendo una lista di tecnologie storage supportate nel prompt di sistema.