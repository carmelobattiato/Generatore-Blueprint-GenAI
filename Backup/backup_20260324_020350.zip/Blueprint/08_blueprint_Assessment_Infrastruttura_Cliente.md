# Blueprint GenAI: Efficentamento del "Assessment Infrastruttura Cliente"

## 1. Descrizione del Caso d'Uso
**Categoria:** Assessment & Analysis
**Titolo:** Assessment Infrastruttura Cliente
**Ruolo:** Infrastructure Consultant
**Obiettivo Originale (da CSV):** Analisi dello stato di fatto dell'infrastruttura IT di un cliente. Include l'inventario degli asset, l'identificazione di colli di bottiglia, vulnerabilità, inefficienze e la produzione di un report con raccomandazioni architetturali.
**Obiettivo GenAI:** Automatizzare l'analisi dei dati grezzi di inventario (es. esportazioni CMDB, log di rete, report di vulnerability scan) per identificare rapidamente criticità, inefficienze e generare automaticamente una bozza strutturata del report di assessment con raccomandazioni architetturali mirate.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion e Analisi dei Dati di Inventario
Il consulente carica i dati grezzi estratti dai sistemi del cliente (file CSV, Excel del CMDB, report PDF di tool di discovery) all'interno di un'interfaccia sicura. L'AI normalizza i dati ed estrae le informazioni chiave sugli asset e le loro relazioni.
*   **Tool Principale Consigliato:** Microsoft Teams (Chatbot UI via Copilot Studio)
*   **Alternative:** 1. Accenture Amethyst (per dati sensibili), 2. ChatGPT Agent (Enterprise)
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4 o Anthropic Claude Opus 4.6 (per la gestione di ampi contesti documentali e dati tabellari complessi).
*   **Modalità di Utilizzo:** Creazione di un Bot su Teams dove il consulente esegue l'upload dei file e fornisce un prompt predefinito.
    ```markdown
    **Prompt per il Bot Teams:**
    "Analizza i documenti allegati contenenti l'inventario hardware/software e i report di discovery del cliente X. Estrai un elenco strutturato degli asset principali, raggruppali per tipologia (Server, Network, Storage) e identifica eventuali sistemi in End of Life (EoL) o componenti obsoleti."
    ```
*   **Azione Umana Richiesta:** Il consulente deve verificare che l'AI abbia mappato correttamente gli asset e non abbia tralasciato sistemi critici presenti nei file originali.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 8 ore (lettura incrociata di fogli di calcolo e report)
    *   *Tempo To-Be (GenAI):* 30 minuti (upload e review dell'output)
    *   *Risparmio %:* ~94%
    *   *Motivazione:* L'LLM elabora e incrocia istantaneamente grandi volumi di dati tabellari e testuali, evidenziando subito le anomalie senza necessità di ricerche manuali tramite filtri Excel.

### Fase 2: Identificazione Criticità e Generazione Report
Basandosi sui dati normalizzati nella Fase 1, l'AI incrocia le informazioni per identificare colli di bottiglia, vulnerabilità note e inefficienze architetturali, redigendo quindi un report professionale in formato Markdown o Word.
*   **Tool Principale Consigliato:** Microsoft Teams (Chatbot UI via Copilot Studio)
*   **Alternative:** 1. Accenture Amethyst
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4 o Google Gemini 3.1 Pro.
*   **Modalità di Utilizzo:** Interazione in continuità di contesto con il Bot.
    ```markdown
    **Prompt per la generazione del report:**
    "Sulla base dell'inventario appena analizzato, genera un 'Assessment Report'. La struttura deve essere: 
    1. Executive Summary. 
    2. Identificazione dei Colli di Bottiglia (focus su storage lenti e colli di rete). 
    3. Analisi delle Vulnerabilità e Inefficienze (focus su sistemi operativi obsoleti e single point of failure). 
    4. Raccomandazioni Architetturali a breve e medio termine. 
    Usa un tono consulenziale e professionale, formattato in Markdown."
    ```
*   **Azione Umana Richiesta:** L'Infrastructure Consultant deve leggere criticamente il report, validare la fattibilità tecnica delle raccomandazioni proposte dall'AI e affinare i dettagli specifici del business del cliente.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore (scrittura e formattazione del documento)
    *   *Tempo To-Be (GenAI):* 45 minuti (generazione e revisione manuale approfondita)
    *   *Risparmio %:* ~87%
    *   *Motivazione:* La stesura del boilerplate documentale e la formattazione dei dati vengono azzerate; l'umano si concentra solo sul controllo di qualità e sul valore aggiunto delle raccomandazioni.

## 3. Descrizione del Flusso Logico
Il flusso inizia all'interno di Microsoft Teams. L'Infrastructure Consultant raccoglie i dati grezzi dal cliente (CSV, PDF) e li fornisce al Chatbot AI dedicato tramite upload diretto nella chat. L'AI processa questi documenti (Fase 1), estraendo l'elenco degli asset e identificando i sistemi obsoleti. Il consulente visiona un riassunto a schermo per confermare che l'ingestion sia corretta. Successivamente (Fase 2), il consulente richiede al Bot di elaborare i dati estrapolati per identificare pattern di vulnerabilità o inefficienze strutturali e di impaginare il tutto in un report di Assessment formattato. Il Bot restituisce il testo del report in chat o genera un file scaricabile. Il consulente esegue la revisione finale, apporta le necessarie correzioni (Human-in-the-loop) e finalizza il documento per il cliente.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    A[Infrastructure Consultant] -->|Interazione via Chat| B[Microsoft Teams UI]
    B -->|Invia Documenti & Prompt| C[Copilot Studio / Bot Engine]
    C -->|API Request| D[LLM - GPT-5.4 / Claude 4.6]
    D -->|Estrazione Dati & Analisi| E[(Data Processing in Memory)]
    E -->|Ritorna Risposte| D
    D -->|Genera Report| C
    C -->|Mostra Output/File| B
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    A[Start: Raccolta dati Cliente] --> B[Upload dati nel Bot Teams]
    B --> C{Dati sufficienti?}
    C -->|No| D[Richiesta ulteriori log/export al Cliente]
    D --> B
    C -->|Sì| E[L'AI elabora inventario ed EoL]
    E --> F[Review Umana dell'Inventario]
    F --> G{Estrazione corretta?}
    G -->|No| H[Raffinamento Prompt]
    H --> E
    G -->|Sì| I[Richiesta generazione Report Assessment]
    I --> J[L'AI genera Documento con Raccomandazioni]
    J --> K[Revisione Umana e Correzioni]
    K --> L[End: Consegna Report al Cliente]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant U as Infrastructure Consultant
    participant T as MS Teams Bot
    participant LLM as LLM Engine
    
    U->>T: Upload file (CSV CMDB, PDF Scan)
    U->>T: Prompt: Analizza asset e identifica EoL
    T->>LLM: Invia file testuali + System Prompt
    LLM-->>T: Risposta: Elenco strutturato asset e anomalie
    T-->>U: Mostra analisi preliminare in chat
    U->>U: Valida dati estratti
    U->>T: Prompt: Genera Report di Assessment
    T->>LLM: Invia richiesta formattazione Report basato sul contesto
    LLM-->>T: Risposta: Testo del Report in Markdown
    T-->>U: Fornisce il testo completo o file .md
    U->>U: Modifica manuale e validazione raccomandazioni
```

## 5. Guida all'Implementazione Tecnica

### Prerequisiti
- Licenza Microsoft 365 con accesso a Copilot Studio (o framework alternativo es. n8n collegato a Teams).
- Abilitazione all'upload di file nei bot di Teams.
- Subscription API per il modello LLM scelto (es. OpenAI Enterprise) o tenant configurato in modo sicuro per evitare la data retention sui dati dei clienti.

### Step 1: Creazione del Bot in Copilot Studio
1. Accedere al portale di Microsoft Copilot Studio.
2. Selezionare "Nuovo Copilot" e assegnare il nome "Infrastructure Assessment Assistant".
3. Nelle impostazioni del Copilot, alla voce **Generative AI**, configurare il comportamento di base definendo un **System Prompt** specifico: 
   *"Sei un esperto Infrastructure Architect Consultant. Il tuo compito è analizzare dati grezzi di infrastrutture IT, identificare criticità, colli di bottiglia e vulnerabilità, e redigere report professionali e oggettivi. Rispondi sempre in italiano, usando un linguaggio tecnico appropriato."*

### Step 2: Abilitazione Gestione File
1. Assicurarsi che nel nodo di "Conversazione" (o Topic principale) sia abilitata la ricezione di allegati.
2. Utilizzare le funzionalità native di "Generative Answers" sui documenti caricati in sessione: il Copilot estrarrà il testo dai file caricati dinamicamente dall'utente senza salvarli in knowledge base permanenti (garantendo la privacy per ogni diverso cliente).

### Step 3: Test e Pubblicazione su Microsoft Teams
1. Testare l'interazione caricando un file CSV fittizio contenente server di test per verificare che l'estrazione dati funzioni correttamente.
2. Spostarsi nella sezione **Publish** di Copilot Studio.
3. Selezionare i canali di distribuzione e attivare **Microsoft Teams**.
4. Inviare l'app per l'approvazione agli amministratori del tenant (se richiesto) o installarla direttamente per il gruppo "Technology & Architecture".

## 6. Rischi e Mitigazioni
- **Rischio 1: Allucinazione dei dati di inventario.** L'AI potrebbe inventare server non presenti o ignorare asset critici presenti in un file mal formattato. 
  -> **Mitigazione:** Il consulente deve sempre eseguire un controllo a campione tra l'output dell'AI e i file Excel originali (Fase 1). Chiedere all'AI di indicare la riga o il nome del file da cui ha estratto l'informazione "critica".
- **Rischio 2: Esposizione di dati sensibili del cliente (Privacy/NDA).** I report del cliente potrebbero contenere IP, hostname o dati sensibili che non devono finire nei dataset di training pubblici. 
  -> **Mitigazione:** Utilizzare ESCLUSIVAMENTE tenant Enterprise (es. Azure OpenAI, Accenture Amethyst, o Copilot Studio in ambiente sicuro) con clausole esplicite di *Zero Data Retention* e *No Training on Customer Data*. Se necessario, anonimizzare i dati prima dell'upload.
- **Rischio 3: Raccomandazioni architetturali generiche o errate.** L'AI potrebbe proporre soluzioni non adatte allo specifico contesto di business del cliente o budget.
  -> **Mitigazione:** L'output dell'AI è considerato una *bozza* (draft). La responsabilità ultima della firma sul report e della validazione delle raccomandazioni spetta sempre all'Infrastructure Consultant umano.