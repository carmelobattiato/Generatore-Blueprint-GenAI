# Blueprint GenAI: Efficentamento del "Analisi Obsolescenza HW-Middleware-SW-SO"

## 1. Descrizione del Caso d'Uso
**Categoria:** Assessment & Analysis
**Titolo:** Analisi Obsolescenza HW-Middleware-SW-SO
**Ruolo:** System Administrator
**Obiettivo Originale (da CSV):** Valutazione sistematica del ciclo di vita di hardware, sistemi operativi, middleware e software di base. Identificazione dei sistemi vicini alla fine del supporto ufficiale (End of Life) e pianificazione degli interventi di refresh.
**Obiettivo GenAI:** Automatizzare il riconoscimento delle date di End of Life (EoL) e End of Support (EoS) partendo da un file di inventario IT (es. CSV/Excel), generando immediatamente un report sui rischi di obsolescenza e sui suggerimenti per gli upgrade.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion Inventario e Identificazione Asset
L'amministratore di sistema carica un file (es. CSV estratto dal CMDB) contenente l'elenco degli asset e le versioni installate direttamente in una chat aziendale. L'AI interpreta il file ed estrae la lista normalizzata dei prodotti.
*   **Tool Principale Consigliato:** Copilot Studio (su Microsoft Teams)
*   **Alternative:** 1. ChatGPT Agent (Enterprise), 2. n8n (per analisi automatica schedulata)
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4
*   **Modalità di Utilizzo:** Creazione di un bot su Teams abilitato al caricamento file e all'analisi dati.
    ```markdown
    # Prompt di Sistema per il Bot Copilot:
    Sei un IT Asset Manager esperto. Riceverai in input il contenuto di un file CSV contenente l'inventario IT.
    Il tuo compito è analizzare i dati ed estrarre per ogni riga le seguenti informazioni chiave: Nome Vendor, Nome Prodotto, Versione.
    Ignora hostname, indirizzi IP o altre informazioni specifiche dell'azienda. Prepara una lista strutturata e univoca dei prodotti per la successiva verifica di obsolescenza.
    ```
*   **Azione Umana Richiesta:** Il System Administrator deve verificare che l'export dal CMDB sia corretto e caricare il file nella chat del Bot.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 2 ore (estrazione, normalizzazione dati e pulizia da stringhe sporche in Excel)
    *   *Tempo To-Be (GenAI):* 2 minuti
    *   *Risparmio %:* 98%
    *   *Motivazione:* L'AI comprende formati destrutturati e normalizza le stringhe di versione quasi istantaneamente, annullando il tempo perso con VLOOKUP o text parsing manuale.

### Fase 2: Check EoL/EoS e Generazione Report
L'AI verifica le date di obsolescenza (tramite le proprie conoscenze aggiornate o mediante web search) per ciascun prodotto/versione identificato, generando una tabella di alert (RAG status: Red/Amber/Green) con i percorsi di aggiornamento consigliati.
*   **Tool Principale Consigliato:** Copilot Studio (con funzionalità Generative Answers abilitata)
*   **Alternative:** 1. Accenture Amethyst, 2. AI-Studio Google
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4
*   **Modalità di Utilizzo:** Il bot esegue il match con le scadenze ufficiali dei vendor e formatta l'output in Teams.
    ```markdown
    # Istruzione di Analisi Obsolescenza:
    Per ogni prodotto estratto nella fase precedente, cerca la data ufficiale di "End of Support" (EoS) o "End of Life" (EoL).
    Genera una singola tabella Markdown riassuntiva con le seguenti colonne:
    | Asset | Versione Attuale | Data EoL/EoS | Stato | Upgrade Suggerito |
    
    Regole per la colonna "Stato":
    - 🔴 Critico se EoL è già superata o scade entro 6 mesi.
    - 🟡 Attenzione se EoL scade tra 6 e 12 mesi.
    - 🟢 Sicuro se EoL scade oltre i 12 mesi.
    
    Mostra i risultati formattati direttamente nella chat.
    ```
*   **Azione Umana Richiesta:** Il System Administrator valuta i risultati della tabella, esegue un double-check sui prodotti più di nicchia o hardware specifico, e usa i dati per pianificare i successivi interventi di refresh.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore (ricerca manuale su siti vendor per decine di versioni differenti)
    *   *Tempo To-Be (GenAI):* 10 minuti
    *   *Risparmio %:* 97%
    *   *Motivazione:* La conoscenza nativa delle scadenze dei principali software (Windows, RHEL, Oracle, VMware, ecc.) da parte del modello elimina le ore di ricerca navigando tra le documentazioni tecniche dei singoli fornitori.

## 3. Descrizione del Flusso Logico
Il System Administrator avvia l'interazione aprendo il Chatbot aziendale "Lifecycle Bot" direttamente su Microsoft Teams. L'operatore carica o incolla i dati di un export CSV del CMDB aziendale contenente lo stato dell'infrastruttura IT. Il bot analizza istantaneamente i dati, ne comprende la struttura (ad esempio riconoscendo le colonne miste con OS, versioni software, hardware model) e deduce l'elenco normalizzato dei prodotti unici. Successivamente, interrogando il suo motore LLM, associa a ciascun componente la relativa data di End of Life o End of Support ufficiale. Infine, l'agente restituisce all'utente nella stessa chat una chiara tabella riassuntiva Markdown dotata di sistema a semaforo (RAG) per l'evidenza visiva dei rischi, oltre ai percorsi di upgrade raccomandati (es. "Upgrade a Windows Server 2022"). Il SysAdmin analizza l'output, valida la veridicità dei suggerimenti e copia la tabella o la usa come base per il proprio report formale di refresh plan.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    A[System Administrator] -->|Chat & Upload File| B[Microsoft Teams Client]
    B -->|API/Graph| C[Copilot Studio Bot]
    C -->|Data Parsing| D[Storage Temporaneo / Context]
    C -->|Prompt & Asset List| E[LLM: OpenAI GPT-5.4]
    E -->|Web Search / KB Interna| F[Dati Lifecycle Vendor]
    E -->|Generazione Tabella| C
    C -->|Report Markdown Formattato| B
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    Start([Inizio]) --> Upload[SysAdmin invia CSV in Teams]
    Upload --> Extract[L'AI estrae Prodotti e Versioni uniche]
    Extract --> Check{Dati leggibili?}
    Check -- No --> Error[Il Bot richiede formato migliore] --> Upload
    Check -- Yes --> Loop[Ciclo Analisi Prodotti]
    Loop --> EoLCheck[Identifica date EoL/EoS]
    EoLCheck --> Evaluate{EoL imminente?}
    Evaluate -- < 6 mesi --> MarkRed[Marca con 🔴 e trova Upgrade]
    Evaluate -- 6-12 mesi --> MarkYellow[Marca con 🟡 e trova Upgrade]
    Evaluate -- > 12 mesi --> MarkGreen[Marca con 🟢]
    MarkRed --> EndLoop
    MarkYellow --> EndLoop
    MarkGreen --> EndLoop
    EndLoop[Fine Analisi Elementi] --> Format[Formatta Tabella RAG in Markdown]
    Format --> Output[Visualizzazione Tabella su Teams]
    Output --> End([Fine])
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant SysAdmin as System Administrator
    participant Teams as MS Teams (Bot UI)
    participant Copilot as Copilot Studio
    participant LLM as OpenAI GPT-5.4
    
    SysAdmin->>Teams: Upload "inventario_hw_sw.csv"
    Teams->>Copilot: Inoltra contenuto file e intento utente
    Copilot->>LLM: Analizza testo ed estrai lista vendor/software unici (Prompt 1)
    LLM-->>Copilot: Ritorna lista normalizzata
    Copilot->>LLM: Trova date EoL e valuta livello di rischio (Prompt 2)
    LLM-->>Copilot: Ritorna dati di obsolescenza e consigli di upgrade
    Copilot->>Copilot: Genera tabella Markdown con alert RAG (Semaforo)
    Copilot-->>Teams: Renderizza risposta in chat
    Teams-->>SysAdmin: Visualizza tabella riassuntiva di assessment
    SysAdmin->>SysAdmin: Valida i dati ed elabora piano di refresh
```

## 5. Guida all'Implementazione Tecnica

### Prerequisiti
- Licenza Microsoft 365 e accesso a Microsoft Copilot Studio (ex Power Virtual Agents).
- Permessi sul tenant aziendale per pubblicare custom app/bot su Microsoft Teams.
- Una base di dati CMDB o strumento di discovery in grado di produrre export CSV semplici (es. ServiceNow, Lansweeper).

### Step 1: Creazione del Bot in Copilot Studio
1. Accedere al portale di [Copilot Studio](https://copilotstudio.microsoft.com/).
2. Cliccare su "Nuovo Copilot", assegnargli il nome `IT Obsolescence Analyzer` e impostare la lingua principale in Italiano.
3. Spuntare, se disponibile nel tenant, la funzionalità di accesso ai caricamenti di file per il bot.

### Step 2: Configurazione del Topic "Analisi Inventario"
1. Andare nella sezione "Topic" (Argomenti) e creare un nuovo topic vuoto.
2. Definire le frasi di attivazione (Triggers): "Analizza obsolescenza", "Valuta ciclo di vita", "Controlla scadenze file".
3. Aggiungere un nodo di azione "Question" (Domanda) che chieda all'utente: "Per favore, carica il file CSV dell'inventario o incolla l'elenco formattato qui sotto.". Salvare la risposta in una variabile globale testuale (es. `InventoryData`).
4. Aggiungere un nodo "Crea una risposta generativa" (Create generative answers).
5. Passare la variabile `InventoryData` come dato di contesto e incollare nei System Instructions del nodo i prompt descritti alla *Fase 1* e *Fase 2*.
6. Assicurarsi di specificare all'LLM di rispondere *esclusivamente* fornendo la tabella in formato Markdown, senza aggiungere convenevoli per non affollare la chat.

### Step 3: Integrazione Canale Teams
1. Conclusa la configurazione, salvare il Topic e andare sulla voce di menù "Canali" (Channels).
2. Selezionare "Microsoft Teams" e abilitare l'integrazione del canale.
3. Copiare l'App ID generato o selezionare l'opzione "Invia per l'approvazione all'amministratore" (a seconda delle policy aziendali).
4. Dopo la pubblicazione, l'app comparirà nel catalogo Teams aziendale e potrà essere appuntata alla barra laterale dal System Administrator.

## 6. Rischi e Mitigazioni
- **Rischio 1: Allucinazioni su Date di EoL non pubbliche o hardware di nicchia** -> **Mitigazione:** Istruire l'AI (nel system prompt) a non inventare date: se un prodotto non è un COTS (Commercial Off-The-Shelf) ben documentato online o se l'informazione non è reperibile, il sistema deve riportare "N/D" nella tabella EoL affinché il sysadmin effettui il check manuale.
- **Rischio 2: Esposizione di Dati Sensibili Architetturali (IP, Hostnames)** -> **Mitigazione:** Il prompt istruisce l'agente a estrarre puramente la tipologia di "Vendor/Prodotto/Versione", epurando a priori hostnames o topologie di rete prima dell'invio dei payload di ricerca. Inoltre, è buona norma procedurale raccomandare esportazioni di CSV pre-filtrate che contengano solo nome software e versione.
- **Rischio 3: Formato file in input mal formattato** -> **Mitigazione:** Se l'AI fallisce l'interpretazione (es. file binario o CSV rotto), inserire un fallback testuale nel bot che suggerisca esplicitamente all'utente come ri-esportare i dati in un formato tabulare pulito.