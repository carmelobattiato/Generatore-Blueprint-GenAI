# Blueprint GenAI: Efficentamento del "Design Alta Affidabilità (HA)"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design
**Titolo:** Design Alta Affidabilità (HA)
**Ruolo:** Infrastructure Architect
**Obiettivo Originale (da CSV):** Progettazione di sistemi resilienti in grado di garantire la continuità operativa anche in caso di guasto di singoli componenti. Esempi includono la configurazione di cluster attivo-attivo, bilanciatori di carico e ridondanza geografica.
**Obiettivo GenAI:** Automatizzare la generazione di una proposta tecnica di architettura HA (High Level Design) partendo dai requisiti applicativi dell'utente, fornendo schemi logici e configurazioni di ridondanza ottimizzate.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion Requisiti via Chat
L'utente interagisce con un bot su Microsoft Teams fornendo i parametri critici (RTO, RPO, stack tecnologico, vincoli di budget e compliance).
*   **Tool Principale Consigliato:** Microsoft Teams (Chatbot UI) tramite Copilot Studio.
*   **Alternative:** 1. Accenture Amethyst, 2. ChatGPT Chatbot (Enterprise).
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro (per l'estrazione strutturata dei requisiti).
*   **Modalità di Utilizzo:** Configurazione di un bot in Copilot Studio che guida l'utente attraverso una serie di domande predefinite (form conversazionale).
*   **Azione Umana Richiesta:** L'architetto inserisce i dati tecnici del progetto specifico.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 2 ore (meeting e raccolta info sparse).
    *   *Tempo To-Be (GenAI):* 10 minuti (chat guidata).
    *   *Risparmio %:* 92%
    *   *Motivazione:* Centralizzazione immediata dei dati senza necessità di follow-up multipli.

### Fase 2: Generazione Draft Architetturale (HLD)
Il sistema elabora i requisiti e genera un documento tecnico di Alta Affidabilità, includendo la strategia di bilanciamento e failover.
*   **Tool Principale Consigliato:** Accenture Amethyst (per gestione sicura dei template documentali).
*   **Alternative:** 1. Gemini-CLI, 2. OpenClaw (per dati strettamente on-premise).
*   **Modelli LLM Suggeriti:** Google Gemini 3 Deep Think (eccellente per il ragionamento complesso su topologie di rete e cluster).
*   **Modalità di Utilizzo:** Invio dei requisiti estratti nella Fase 1 a un Agent specializzato in Infrastructure Design.
    *   **Bozza System Prompt:**
        ```text
        Sei un Senior Infrastructure Architect esperto in Cloud e On-Premise HA.
        Riceverai: [Requisiti Utente].
        Produci un documento HLD che includa:
        1. Strategia Cluster (Attivo/Attivo vs Attivo/Passivo).
        2. Configurazione Load Balancer (L4/L7).
        3. Meccanismo di Health Check.
        4. Strategia di Disaster Recovery/Ridondanza Geografica.
        Usa un linguaggio tecnico preciso e allineato agli standard T&A.
        ```
*   **Azione Umana Richiesta:** Revisione tecnica del design generato per garantire l'aderenza ai protocolli di sicurezza aziendali.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore (stesura HLD e calcolo metriche).
    *   *Tempo To-Be (GenAI):* 20 minuti (generazione e prima revisione).
    *   *Risparmio %:* 94%
    *   *Motivazione:* L'AI genera istantaneamente la struttura e i contenuti tecnici basandosi su best-practice consolidate.

### Fase 3: Generazione Diagrammi di Flusso e Topologia
Traduzione del design testuale in schemi visuali Mermaid.js pronti per essere inseriti in documentazione Git o Wiki.
*   **Tool Principale Consigliato:** Gemini-CLI (tramite script di automazione).
*   **Alternative:** 1. Copilot Studio (output testuale), 2. Visual Studio Code + Copilot.
*   **Modelli LLM Suggeriti:** Anthropic Claude Sonnet 4.6 (superiore nella generazione di sintassi strutturata come Mermaid).
*   **Modalità di Utilizzo:** Lo script riceve l'HLD della Fase 2 e genera i blocchi di codice Mermaid.
*   **Azione Umana Richiesta:** Copia-incolla del codice nel repository di progetto e verifica visuale.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 3 ore (disegno manuale su tool grafici).
    *   *Tempo To-Be (GenAI):* 5 minuti.
    *   *Risparmio %:* 97%
    *   *Motivazione:* Eliminazione del tempo di editing grafico manuale.

## 3. Descrizione del Flusso Logico
Il flusso inizia su **Microsoft Teams**, dove l'Architect inserisce i parametri tramite un bot. I dati vengono passati a un Agent LLM su **Accenture Amethyst** che redige il documento tecnico. Infine, un modulo specializzato genera i diagrammi **Mermaid** per la visualizzazione. L'umano interviene solo per validare le scelte critiche (es. scelta del provider di ridondanza geografica).

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
  User((Infrastructure Architect)) --> Teams[Microsoft Teams UI]
  Teams --> CS[Copilot Studio / n8n]
  CS --> GeminiAPI[Google Gemini 3 API]
  GeminiAPI --> Amethyst[Accenture Amethyst / Doc Generator]
  Amethyst --> Output[HLD Document + Mermaid Code]
  Output --> Wiki[Project Wiki / Git Repo]
```

### 4.2 Process Diagram
```mermaid
flowchart TD
  A[Start: Inserimento Requisiti HA] --> B{Validazione Input?}
  B -- No --> A
  B -- Si --> C[Generazione HLD via LLM]
  C --> D[Generazione Diagrammi Mermaid]
  D --> E[Review Architetto]
  E -- Modifiche --> C
  E -- Approvato --> F[Pubblicazione Documentazione]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
  participant Architect as Architetto
  participant Bot as Teams Bot (Copilot Studio)
  participant LLM as Gemini 3 Deep Think
  
  Architect->>Bot: Inserisce RTO/RPO e Stack
  Bot->>LLM: Richiesta generazione design HA
  LLM-->>Bot: Ritorna Draft HLD e Mermaid Code
  Bot-->>Architect: Presenta proposta per approvazione
  Architect->>Bot: Approva e richiede pubblicazione
```

## 5. Guida all'Implementazione Tecnica

### Prerequisiti
- Licenza Microsoft 365 con accesso a **Copilot Studio**.
- Accesso ad **Accenture Amethyst** o API Key per **Google Gemini 3**.
- Repository Git o Wiki aziendale che supporti il rendering Mermaid.

### Step 1: Configurazione Copilot Studio
1. Accedi al portale Copilot Studio.
2. Crea un nuovo bot denominato "HA Design Assistant".
3. Configura i "Topics" per raccogliere: Nome Progetto, Livello di Criticità, Stack Tecnologico, RTO/RPO target.
4. Collega il bot tramite Webhook a un workflow (es. n8n o Power Automate) che interroga l'LLM.

### Step 2: Definizione del Prompt di Generazione
Carica nel sistema (o nello script) il seguente prompt per la generazione del diagramma:
```text
Converti la seguente architettura HA in un diagramma Mermaid graph TD:
[TESTO HLD GENERATO]
Assicurati di includere Load Balancer, Cluster Nodes e Storage Replication.
```

### Step 3: Pubblicazione su Teams
1. Vai nella sezione "Publish" di Copilot Studio.
2. Seleziona il canale "Microsoft Teams".
3. Distribuisci il bot al team "Architecture & Design".

## 6. Rischi e Mitigazioni
- **Rischio 1: Dimensionamento errato delle risorse** -> **Mitigazione:** Il design generato deve sempre essere sottoposto a validazione dell'Architect prima dell'approvazione finale.
- **Rischio 2: Allucinazioni su feature specifiche di vendor (es. AWS/Azure)** -> **Mitigazione:** Utilizzare "Grounding" fornendo all'LLM la documentazione aggiornata dei servizi cloud tramite RAG (Retrieval Augmented Generation) su Amethyst.
