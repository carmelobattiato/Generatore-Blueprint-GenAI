# Blueprint GenAI: Efficentamento del "Realizzazione Documentazione Tecnica"

## 1. Descrizione del Caso d'Uso
**Categoria:** Documentation
**Titolo:** Realizzazione Documentazione Tecnica
**Ruolo:** Technical Writer
**Obiettivo Originale (da CSV):** Stesura e aggiornamento continuo di documenti come High Level Design (HLD), Low Level Design (LLD), manuali operativi e as-built. Attività fondamentale per il passaggio in esercizio e per mantenere la conoscenza storica dei sistemi.
**Obiettivo GenAI:** Automatizzare e velocizzare la stesura delle prime bozze, la formattazione e l'aggiornamento continuo dei documenti architetturali e operativi (HLD, LLD, Manuali) partendo da appunti informali, diagrammi e file di configurazione grezzi.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion del Contesto Tecnico
Caricamento degli appunti, frammenti di codice, script IaC, diagrammi architetturali e vecchi manuali all'interno di un sistema AI per fornire tutto il contesto tecnico necessario alla stesura.
*   **Tool Principale Consigliato:** `accenture ametyst`
*   **Alternative:** 1. `chatgpt agent`, 2. `Microsoft Teams (Chatbot UI)`
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro (ottimale per contesti lunghi e diagrammi) o OpenAI GPT-5.4
*   **Modalità di Utilizzo:** Interfaccia chat enterprise con funzionalità di upload documentale multiplo.
*   **Azione Umana Richiesta:** Il Technical Writer deve selezionare, sanitizzare da eventuali credenziali e caricare i documenti sorgente corretti, verificando che il contesto fornito all'AI sia completo.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 2 ore (ricerca e collazione materiali)
    *   *Tempo To-Be (GenAI):* 10 minuti
    *   *Risparmio %:* 91%
    *   *Motivazione:* L'AI aggrega istantaneamente dati provenienti da formati eterogenei (PDF, testo, immagini, codice) creando un'unica base di conoscenza interrogabile.

### Fase 2: Generazione e Formattazione del Documento
Generazione della struttura e dei contenuti del documento (HLD, LLD o Manuale Operativo) basata su un template aziendale e sul contesto tecnico caricato nella Fase 1.
*   **Tool Principale Consigliato:** `accenture ametyst`
*   **Alternative:** 1. `chatgpt agent`
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro / OpenAI GPT-5.4
*   **Modalità di Utilizzo:** Prompting strutturato per istruire l'AI a compilare specifici paragrafi del template aziendale.
    ```text
    Agisci come Technical Writer esperto. Basandoti sui file di configurazione, sugli script e sugli appunti architetturali allegati, genera una prima bozza dettagliata del Low Level Design (LLD). 
    Usa rigorosamente il seguente template:
    1. Introduzione e Scopo
    2. Architettura di Dettaglio
    3. Tabella Flussi di Rete (Sorgente, Destinazione, Porta, Protocollo)
    4. Requisiti e Prerequisiti
    
    Regole:
    - Formatta l'output in Markdown pulito.
    - Non inventare indirizzi IP o server non presenti nei file allegati.
    - Se un'informazione richiesta nel template non è presente nel contesto fornito, inserisci il segnaposto "[DA VERIFICARE INSIEME AL TEAM]".
    ```
*   **Azione Umana Richiesta:** Lettura critica, validazione "riga per riga" delle informazioni tecniche prodotte e risoluzione dei punti contrassegnati come "[DA VERIFICARE...]".
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 8 ore (stesura da zero)
    *   *Tempo To-Be (GenAI):* 45 minuti (generazione e prima revisione)
    *   *Risparmio %:* 90%
    *   *Motivazione:* L'AI elimina il "blocco della pagina bianca" e automatizza la noiosa conversione di logiche di codice in linguaggio naturale e tabelle formattate.

### Fase 3: Iterazione e Generazione As-Built
Inserimento delle variazioni post-implementazione nel sistema AI per aggiornare rapidamente l'LLD esistente e generare il documento definitivo "As-Built".
*   **Tool Principale Consigliato:** `accenture ametyst`
*   **Alternative:** 1. `gemini-cli` (per elaborazione veloce di file testuali locali)
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro
*   **Modalità di Utilizzo:** Prompting delta-update sui documenti elaborati.
    ```text
    Ti allego il documento LLD attuale. Aggiornalo trasformandolo in un documento "As-Built", applicando ESATTAMENTE le seguenti modifiche occorse durante il passaggio in produzione:
    - Il server DB primario ha ora l'IP 10.0.5.20
    - La porta per il traffico applicativo è cambiata da 8080 a 8443 (HTTPS)
    Fornisci in output l'intero documento Markdown aggiornato.
    ```
*   **Azione Umana Richiesta:** Approvazione finale del documento aggiornato e sua pubblicazione formale sul repository documentale (es. SharePoint, Confluence).
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 3 ore (ricerca e sostituzione capillare)
    *   *Tempo To-Be (GenAI):* 15 minuti
    *   *Risparmio %:* 91%
    *   *Motivazione:* Sostituzioni chirurgiche, aggiornamento di contesti e coerenza di rete vengono gestite dall'AI in un singolo passaggio anziché richiedere letture umane multiple.

## 3. Descrizione del Flusso Logico
Il Technical Writer inizia raccogliendo gli input frammentati (appunti sparsi, export di diagrammi, script di automazione) dal team di ingegneria o di delivery. Questi materiali grezzi vengono caricati nella chat sicura di Accenture Amethyst (o piattaforma equivalente approvata). L'AI analizza i documenti ed elabora una bozza strutturata dell'HLD o dell'LLD seguendo un template aziendale predefinito. Il Technical Writer rivede la bozza, iterando rapidamente con l'AI tramite chat per colmare lacune, approfondire passaggi o correggere formattazioni. Una volta che il sistema va in produzione, il Technical Writer carica le note di rilascio finali e chiede all'AI di applicare i delta per generare la versione "As-Built", che viene infine esportata e salvata nei repository aziendali (SharePoint/Confluence).

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    TW[Technical Writer] -->|Carica Appunti/Codice/Diagrammi| UI(Accenture Amethyst / Chat Enterprise)
    UI -->|API Secure Request| LLM[LLM: Gemini 3.1 Pro / GPT-5.4]
    LLM -->|Risposta Markdown Documentale| UI
    UI -->|Copia o Esportazione| DOC[Editor Testuale/Word]
    DOC -->|Pubblicazione Ufficiale| REPO[(SharePoint / Confluence)]
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    Start[Inizio Processo] --> Upload[Upload Dati Sorgente su Piattaforma AI]
    Upload --> Generate[Esecuzione Prompt di Generazione Bozza]
    Generate --> Review{Revisione Umana}
    Review -->|Inesattezze / Dati Mancanti| Iteration[Iterazione Prompt per Correzioni]
    Iteration --> Review
    Review -->|Bozza Approvata| GoLive{Passaggio in Esercizio?}
    GoLive -->|Sì| Update[Upload Delta/Modifiche]
    Update --> AsBuilt[Generazione Documento As-Built]
    AsBuilt --> Publish[Pubblicazione Documento Finale su Repository]
    GoLive -->|No| Publish
    Publish --> End[Fine]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant TW as Technical Writer
    participant AI as Chat Enterprise (Amethyst)
    participant LLM as Modello LLM
    participant Repo as SharePoint/Confluence
    TW->>AI: Upload frammenti (script, appunti, diagrammi)
    TW->>AI: Inserimento Prompt: "Genera LLD da template"
    AI->>LLM: Invia contesto documentale + Prompt
    LLM-->>AI: Ritorna bozza LLD strutturata in Markdown
    AI-->>TW: Visualizza output in chat
    TW->>AI: Richiede aggiunta (es. "Rifinisci tabella flussi")
    AI->>LLM: Invia nuovo prompt di raffinamento
    LLM-->>AI: Ritorna sezione aggiornata
    AI-->>TW: Visualizza documento finale
    TW->>Repo: Salva e pubblica il documento approvato
```

## 5. Guida all'Implementazione Tecnica

### Prerequisiti
- Accesso ad Accenture Amethyst o a una piattaforma LLM Enterprise equivalente (garanzia di data privacy on-premise o zero-retention).
- Repository documentale di destinazione accessibile (es. SharePoint, OneDrive, Confluence).
- Template documentali standard aziendali (HLD, LLD, As-Built) convertiti in formato Markdown per il copia-incolla rapido nei prompt.

### Step 1: Preparazione e Standardizzazione dei Template
1. Estrarre i template Word in uso in azienda per HLD e LLD.
2. Convertirne la struttura ad albero in formato testuale Markdown pulito (usare `#` per titoli, `##` per sottotitoli).
3. Salvare questi "Template Markdown" in una cartella locale in modo che il Technical Writer possa copiarli facilmente.

### Step 2: Utilizzo della Piattaforma AI (Ingestion)
1. Aprire una nuova sessione isolata (thread) su Accenture Amethyst.
2. Utilizzare l'icona dell'allegato (📎) per caricare i file tecnici relativi al progetto: un file `.tf` di Terraform, un export in `.pdf` del diagramma draw.io, eventuali txt di appunti presi in riunione.

### Step 3: Generazione e Validazione
1. Nella casella di testo, incollare il prompt indicato nella Fase 2.
2. Sotto il prompt, incollare il contenuto del "Template Markdown" preparato allo Step 1.
3. Eseguire l'invio. L'AI genererà il documento estraendo i dati tecnici dai file allegati.
4. Rivedere il testo a schermo: verificare specificamente tabelle e IP, e colmare manualmente i campi etichettati con `[DA VERIFICARE INSIEME AL TEAM]`.

### Step 4: Esportazione Finale
1. Copiare l'output validato.
2. Incollarlo in Word (utilizzando "Mantieni formattazione" o convertitori da Markdown a Docx per preservare tabelle e stili).
3. Applicare eventuali stili e loghi finali e caricare su SharePoint.

## 6. Rischi e Mitigazioni
- **Rischio 1: Allucinazioni di dati tecnici critici** (L'AI potrebbe "inventare" configurazioni, IP di rete o porte che sembrano plausibili ma sono errate). 
  -> **Mitigazione:** Istruire obbligatoriamente l'AI (via prompt) a non dedurre informazioni mancanti ma ad inserire tag espliciti come `[DA VERIFICARE]`. Obbligo ferreo di revisione "Human-in-the-loop" da parte dell'architetto prima dell'approvazione formale.
- **Rischio 2: Esposizione di secrets aziendali** (Upload involontario di script contenenti password o chiavi API nell'AI). 
  -> **Mitigazione:** Obbligo procedurale di usare tool di sanitizzazione o eliminazione manuale dei secrets prima dell'upload. Utilizzo esclusivo di piattaforme Enterprise (es. Amethyst) che non usano i dati in input per addestrare modelli futuri.
- **Rischio 3: Perdita dello standard aziendale** (Output creativi che deviano dai format richiesti).
  -> **Mitigazione:** Imporre rigorosamente nel prompt l'uso di template Markdown chiusi e limitare le istruzioni stilistiche dell'LLM (Zero-Shot prompting controllato).