#!/bin/bash

# Script per creare un backup dell'intera directory di lavoro
# I file verranno salvati nella cartella "Backup" con un nome basato su data e ora.

# 1. Creazione della cartella Backup se non esiste
mkdir -p Backup

# 2. Generazione del timestamp nel formato YYYYMMDD_HHMMSS
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# 3. Nome del file di backup
BACKUP_FILE="Backup/backup_${TIMESTAMP}.zip"

echo "Inizio creazione del backup: $BACKUP_FILE"

# 4. Compressione di tutti i file e cartelle, escludendo esplicitamente la cartella Backup stessa
# L'opzione -r zippa ricorsivamente, l'opzione -x esclude i pattern specificati.
zip -r "$BACKUP_FILE" . -x "Backup/*" -x ".*" > /dev/null

if [ $? -eq 0 ]; then
    echo "✅ Backup completato con successo: $BACKUP_FILE"
else
    echo "❌ Errore durante la creazione del backup."
    exit 1
fi
