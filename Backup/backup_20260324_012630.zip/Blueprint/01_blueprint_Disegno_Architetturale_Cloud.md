# Blueprint GenAI: Efficentamento del "Disegno Architetturale Cloud"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design  
**Titolo:** Disegno Architetturale Cloud  
**Ruolo:** Cloud Architect  
**Obiettivo Originale (da CSV):** Progettazione dell'architettura di base per ambienti cloud (pubblici, privati o ibridi). Include la definizione di reti virtuali, subnetting, regole di routing e componenti di base necessari per ospitare le applicazioni aziendali, assicurando scalabilità e sicurezza fin dal principio, come base per le blueprint future.  
**Obiettivo GenAI:** Automatizzare la generazione di documenti di High-Level Design (HLD), schemi di rete (in formato testuale/code-to-diagram) e matrici di routing partendo da requisiti di business espressi in linguaggio naturale, garantendo l'aderenza ai framework di sicurezza aziendali.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion Requisiti via Conversazione
L'architetto interagisce con un bot su Microsoft Teams per definire il perimetro del progetto (es. numero di tier applicativi, region, requisiti di isolamento).
*   **Tool Principale Consigliato:** Microsoft Teams (Chatbot UI) tramite **Copilot Studio**.
*   **Alternative:** 1. Accenture Amethyst, 2. ChatGPT Agent.
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4 (ottimizzato per interazioni agentiche e reasoning strutturato).
*   **Modalità di Utilizzo:** Configurazione di un Agent in Copilot Studio che agisce come "Interviewer Tecnico".
    *   **Bozza System Prompt:**
        ```text
        Sei un Cloud Architecture Assistant. Il tuo compito è raccogliere requisiti per un nuovo ambiente cloud. 
        Domanda specificamente: 1. Cloud Provider (Azure/AWS/GCP), 2. Numero di subnet richieste, 3. Requisiti di connettività on-prem (VPN/ExpressRoute), 4. Livello di criticità (SLA). 
        Formatta i dati raccolti in un JSON strutturato da passare alla fase successiva.
        ```
*   **Stima Reale di Efficienza:** Risparmio del 40% - Elimina la necessità di scrivere manualmente i verbali di raccolta requisiti e standardizza l'input.

### Fase 2: Generazione Documentazione HLD e Schemi
Il sistema elabora il JSON e produce una bozza completa di documento HLD e il codice per generare il diagramma (Mermaid.js).
*   **Tool Principale Consigliato:** Accenture Amethyst (per garantire la privacy dei dati architettonici).
*   **Alternative:** 1. Gemini-cli, 2. VisualStudio + Copilot (se si scrive il design come codice).
*   **Modelli LLM Suggeriti:** Google Gemini 3 Deep Think (eccellente per ragionamento complesso su topologie di rete e dipendenze).
*   **Modalità di Utilizzo:** Scripting via API che invia i requisiti e riceve un template Markdown pre-compilato.
    *   **Bozza Prompt di Generazione:**
        ```text
        Basandoti sui seguenti requisiti [JSON_DATA], genera un documento HLD in Markdown che includa:
        - Descrizione della VNET/VPC e delle Subnet (CIDR planning).
        - Regole di Network Security Group (NSG) consigliate.
        - Codice Mermaid per un diagramma dell'architettura.
        Usa i nomi standard definiti nella Naming Convention aziendale T&A.
        ```
*   **Stima Reale di Efficienza:** Risparmio del 70% - La stesura di un HLD complesso scende da ore a pochi minuti di revisione.

### Fase 3: Validazione Compliance e Cost Estimation
Analisi automatica del design prodotto rispetto alle policy di sicurezza e stima dei costi a consumo.
*   **Tool Principale Consigliato:** OpenClaw (per analisi on-premise di dati sensibili di costo/policy).
*   **Alternative:** 1. Gemini-cli, 2. Custom Python Script con LLM.
*   **Modelli LLM Suggeriti:** Meta Llama 4 Scout (109B) via OpenClaw.
*   **Modalità di Utilizzo:** L'LLM agisce come "Security Auditor" controllando se il design include componenti critici (es. WAF, Bastion) richiesti dalle policy.
*   **Stima Reale di Efficienza:** Risparmio del 30% - Riduce i cicli di revisione con il team Security.

## 3. Descrizione del Flusso Logico
Il flusso parte da **Microsoft Teams**, dove l'architetto risponde a una serie di domande guidate dal bot. I dati vengono trasformati in un payload JSON inviato a **Gemini 3 Deep Think** (tramite Amethyst o API diretta), che elabora la topologia di rete ottimale e scrive il documento HLD in formato Markdown, includendo blocchi di codice **Mermaid** per la visualizzazione grafica. Infine, l'architetto riceve il documento su Teams o SharePoint per la revisione finale e l'approvazione ("Human-in-the-loop").

## 4. Diagrammi UML (ASCII Art)

### 4.1 Architecture Diagram
```text
+-----------------------+      +---------------------------+      +-----------------------+
|  Microsoft Teams      |      |     Copilot Studio        |      |  Accenture Amethyst   |
|  (User Interface)     |----->|     (Orchestratore)       |----->|  (LLM Engine - GPT-5) |
+-----------------------+      +---------------------------+      +-----------|-----------+
                                            |                                 |
                                            v                                 v
                               +---------------------------+      +-----------------------+
                               |    SharePoint / Git       |      |   Gemini 3 Deep Think |
                               |    (Document Storage)     |<-----|   (HLD & Diagram Gen) |
                               +---------------------------+      +-----------------------+
```

### 4.2 Process Diagram
```text
[START] --> [Input Requisiti via Teams Bot]
               |
               v
[Generazione JSON Strutturato] --> [Validazione Policy Sicurezza (LLM)]
               |                            |
               |                            +-- [IF KO: Richiedi Correzione] --+
               |                                                              |
               v                                                              |
[Generazione HLD Markdown + Mermaid Diagram] <--------------------------------+
               |
               v
[Revisione Umana (Cloud Architect)] --> [IF OK] --> [Salvataggio & Pubblicazione]
               |                                           |
               +-- [IF NO: Edit manuale/Prompt update] ----+-- [END]
```

### 4.3 Sequence Diagram
```text
Utente (Architect)      Teams Bot (Copilot)      LLM (Gemini 3)       Repository (SP)
       |                        |                    |                    |
       |--- Invia Requisiti --->|                    |                    |
       |                        |--- Analisi/JSON -->|                    |
       |                        |                    |--- Genera HLD ---->|
       |                        |<-- HLD Generato ---|                    |
       |<-- Notifica Pronto ----|                    |                    |
       |                        |                    |                    |
       |--- Approva/Revisiona ->|                    |                    |
       |                        |---------------------------------------->| Salva Versione Finale
```

## 5. Guida all'Implementazione Tecnica

### Step 1: Configurazione Copilot Studio
1.  Accedi al portale **Copilot Studio**.
2.  Crea un nuovo Copilot denominato "Cloud Design Assistant".
3.  Definisci i "Topics" di conversazione per raccogliere: Nome Progetto, Cloud Provider, Tiering, Compliance Level.
4.  Configura un'azione "Call an Action" (Power Automate) per inviare i dati raccolti come stringa JSON.

### Step 2: Prompt Engineering per Generazione HLD
1.  Crea un Agent (o usa un'interfaccia API) configurato con il modello **Gemini 3 Deep Think**.
2.  Inserisci il System Prompt che definisce lo standard HLD aziendale (sezioni obbligatorie, stili Mermaid).
3.  Assicurati che l'output sia formattato rigorosamente in **Markdown** per facilitare la conversione in PDF o Wiki.

### Step 3: Integrazione Canale Teams
1.  In Copilot Studio, vai nella sezione **Channels**.
2.  Seleziona **Microsoft Teams** e clicca su "Turn on Teams".
3.  Pubblica il bot e distribuiscilo ai membri del team Cloud Architecture.

### Step 4: Visualizzazione Diagrammi
1.  Il codice Mermaid generato può essere visualizzato direttamente se il repository (es. Azure DevOps Wiki o GitHub) lo supporta.
2.  In alternativa, suggerire all'utente di incollare il codice su `mermaid.live` per l'esportazione rapida in PNG/SVG.
