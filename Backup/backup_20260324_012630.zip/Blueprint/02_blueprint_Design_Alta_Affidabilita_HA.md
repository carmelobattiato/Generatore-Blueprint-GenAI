# Blueprint GenAI: Efficentamento del "Design Alta Affidabilità (HA)"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design  
**Titolo:** Design Alta Affidabilità (HA)  
**Ruolo:** Infrastructure Architect  
**Obiettivo Originale (da CSV):** Progettazione di sistemi resilienti in grado di garantire la continuità operativa anche in caso di guasto di singoli componenti. Esempi includono la configurazione di cluster attivo-attivo, bilanciatori di carico e ridondanza geografica.  
**Obiettivo GenAI:** Automatizzare la generazione di architetture resilienti e la relativa documentazione tecnica (HLD) a partire dai requisiti di business (SLA, RTO, RPO) e dai vincoli tecnologici, riducendo drasticamente il tempo di drafting iniziale per gli Infrastructure Architect.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion dei Requisiti e Vincoli (SLA/RPO/RTO)
L'architetto interagisce con un bot per definire i parametri critici del sistema (es. "Ho bisogno di un database PostgreSQL con RTO < 5 min e ridondanza geografica").
*   **Tool Principale Consigliato:** Microsoft Teams (Chatbot UI) tramite Copilot Studio.
*   **Alternative:** 1. Accenture Amethyst, 2. ChatGPT Agent.
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4 (per capacità agentiche e comprensione dei parametri).
*   **Modalità di Utilizzo:** Configurazione di un Copilot in Teams che funge da "Interview Architect". Il bot pone domande mirate per estrarre SLA, budget, stack tecnologico e criticità.
    *   **Bozza System Prompt:**
        ```markdown
        Sei un Senior Infrastructure Architect specializzato in High Availability. 
        Il tuo compito è intervistare l'utente per raccogliere:
        1. RTO (Recovery Time Objective) e RPO (Recovery Point Objective).
        2. Carico previsto (TPS, utenti simultanei).
        3. Stack tecnologico preferito (Cloud, On-prem, Hybrid).
        4. Budget indicativo (Low, Medium, High).
        Non suggerire soluzioni finché non hai tutti i dati.
        ```
*   **Stima Reale di Efficienza:** Risparmio del 40% sul tempo di raccolta requisiti e analisi preliminare.

### Fase 2: Generazione del Design Architetturale HA
L'LLM elabora i dati raccolti e produce una proposta tecnica dettagliata (cluster, bilanciatori, meccanismi di failover).
*   **Tool Principale Consigliato:** Accenture Amethyst (per protezione dati sensibili) o gemini-cli.
*   **Alternative:** 1. OpenClaw (on-premise), 2. Google Gemini 3 Deep Think.
*   **Modelli LLM Suggeriti:** Google Gemini 3 Deep Think (per ragionamento complesso sulla ridondanza e logica di failover).
*   **Modalità di Utilizzo:** Invio dei requisiti consolidati a un Agent specializzato che produce un documento Markdown con il design HA consigliato.
    *   **Bozza del Prompt di Generazione:**
        ```text
        Basandoti sui seguenti requisiti: [INPUT_BOT], progetta un'architettura ad Alta Affidabilità.
        Includi:
        - Schema dei componenti (LB, App Nodes, DB Nodes).
        - Strategia di replica (Sync/Async).
        - Meccanismo di Health Check e Failover.
        - Analisi dei Single Point of Failure (SPOF).
        Produci l'output in formato Markdown tecnico.
        ```
*   **Stima Reale di Efficienza:** Risparmio del 70% nella stesura della prima bozza del High Level Design (HLD).

### Fase 3: Validazione e Generazione Diagrammi
Generazione automatica di diagrammi Mermaid/ASCII per visualizzare l'architettura HA.
*   **Tool Principale Consigliato:** Visual Studio + Copilot (per integrazione Mermaid).
*   **Alternative:** 1. AI-Studio Google (per build di una dashboard visuale), 2. n8n (per invio via mail del PDF).
*   **Modelli LLM Suggeriti:** Anthropic Claude 4.6 Sonnet (per l'eccellente precisione nella generazione di codice Mermaid.js).
*   **Modalità di Utilizzo:** L'LLM trasforma la descrizione testuale della Fase 2 in codice Mermaid.js che l'architetto può visualizzare istantaneamente in VS Code o Teams.
*   **Stima Reale di Efficienza:** Risparmio dell'80% rispetto al disegno manuale su tool grafici tradizionali (Visio/Lucidchart).

## 3. Descrizione del Flusso Logico
Il processo inizia su **Microsoft Teams**, dove l'Infrastructure Architect inserisce i dati tramite una chat guidata. Una volta completata l'intervista, il bot invia il payload a un workflow **n8n** (o direttamente all'LLM via **Amethyst**) che genera la proposta tecnica. L'architetto riceve una bozza di documento HLD comprensiva di diagrammi Mermaid. L'umano interviene solo per la revisione finale ("Human-in-the-loop"), validando se la soluzione proposta rispetta i vincoli di compliance aziendale.

## 4. Diagrammi UML (ASCII Art)

### 4.1 Architecture Diagram
```text
+-------------------+       +-----------------------+       +-----------------------+
|  UTENTE (Teams)   | <---> | Copilot Studio (Bot)  | <---> | n8n / Orchestrator    |
+-------------------+       +-----------------------+       +-----------------------+
                                                                     |
                                                                     v
+-------------------+       +-----------------------+       +-----------------------+
|   Sistemi Target  | <---- |   Gemini 3 / GPT-5    | <---> |   Accenture Amethyst  |
| (Repo HLD/Docs)   |       | (Reasoning & Design)  |       | (Security Layer)      |
+-------------------+       +-----------------------+       +-----------------------+
```

### 4.2 Process Diagram
```text
[START] --> (Input Requisiti HA su Teams)
               |
               v
(Analisi LLM: SLA/RPO/RTO) --> {SLA > 99.9%?}
               |                      |
      [SI: Multi-Region]       [NO: Multi-AZ/Cluster]
               |                      |
               v                      v
(Generazione Bozza HLD Markdown + Diagrammi Mermaid)
               |
               v
(Revisione Umana Architect) --> [APPROVATO?] -- NO --> (Modifica Prompt/Parametri)
               |
               v
             [END: HLD Salvato su SharePoint]
```

### 4.3 Sequence Diagram
```text
Architect       Teams Bot       n8n Workflow     LLM (Gemini 3)    SharePoint
    |               |               |                |                |
    |--Inserisce SLA-->|            |                |                |
    |               |--Dati Input-->|                |                |
    |               |               |--Richiesta HA->|                |
    |               |               |                |                |
    |               |               |<--HLD + Code---|                |
    |               |<--Bozza HLD---|                |                |
    |--Approvazione-|               |                |                |
    |               |--Salvataggio->|----------------|--------------->|
    |               |               |                |                |
```

## 5. Guida all'Implementazione Tecnica

### Step 1: Configurazione Copilot Studio (Teams)
1. Accedi al portale **Copilot Studio**.
2. Crea un nuovo Copilot chiamato "HA Architect Assistant".
3. Definisci i **Topic** di conversazione per raccogliere RTO, RPO e stack tecnologico.
4. Usa le "Entity" per estrarre numeri e termini tecnici dai messaggi dell'utente.
5. Configura un'azione per inviare i dati raccolti a un webhook (n8n o Power Automate).

### Step 2: Orchestrazione con n8n
1. Crea un workflow in **n8n** con un trigger HTTP Webhook.
2. Aggiungi un nodo **AI Agent** o **HTTP Request** per invocare l'LLM (es. via API di Google Gemini o Azure OpenAI).
3. Inserisci nel prompt le variabili ricevute dal bot di Teams.
4. Formatta l'output in Markdown pulito.

### Step 3: Generazione Diagrammi e Output
1. Chiedi all'LLM di includere blocchi di codice `mermaid` per il diagramma architetturale.
2. Usa un nodo n8n "Markdown to PDF" (opzionale) se è richiesta la consegna formale, oppure invia semplicemente il testo Markdown in una risposta di Teams per una review rapida.
3. Pubblica il bot su Teams tramite la sezione "Channels" di Copilot Studio.
