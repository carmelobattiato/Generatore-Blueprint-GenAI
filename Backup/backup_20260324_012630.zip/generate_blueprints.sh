#!/bin/bash

# Script per generare massivamente le blueprint tramite Gemini CLI
# Uso: ./generate_blueprints.sh <usecase_inizio> <usecase_fine>
# Esempio: ./generate_blueprints.sh 1 5 (elabora dal 1° al 5° usecase del CSV)

if [ "$#" -ne 2 ]; then
    echo "Uso: $0 <inizio> <fine>"
    echo "Esempio: $0 1 5 (elabora dal 1° al 5° usecase del CSV, saltando l'intestazione)"
    exit 1
fi

START_LINE=$1
END_LINE=$2
CSV_FILE="attivita_infrastrutture_TA.csv"
AGENT_FILE="agent_generatore_blueprint.md"

if [ ! -f "$CSV_FILE" ]; then
    echo "Errore: File CSV '$CSV_FILE' non trovato."
    exit 1
fi

if [ ! -f "$AGENT_FILE" ]; then
    echo "Errore: File Agent '$AGENT_FILE' non trovato."
    exit 1
fi

# Creazione della cartella Blueprint se non esiste
mkdir -p Blueprint

echo "Inizio elaborazione delle righe da $START_LINE a $END_LINE..."

# Estrazione delle righe dal file CSV tramite awk e ciclo while.
# Si ignora l'intestazione (NR>1) e si calcola l'ID dell'usecase tramite la prima colonna ($1).
awk -v start="$START_LINE" -v end="$END_LINE" -F';' 'NR>1 && $1>=start && $1<=end {
    # Verifica che la riga non sia vuota
    if(length($1) > 0) {
        # Stampa i campi separati da un pipe sicuro per il read
        printf "%02d|%s|%s|%s|%s\n", $1, $2, $3, $4, $5
    }
}' "$CSV_FILE" | while IFS='|' read -r ID CATEGORIA TITOLO DESCRIZIONE RUOLO; do
    
    echo "---------------------------------------------------------"
    echo "Elaborazione riga CSV [$ID] - Attività: $TITOLO"
    
    # Costruzione del prompt basato sui requisiti attesi dall'agente, tenendolo su una singola riga per evitare problemi con la CLI
    USER_PROMPT="- ID Riga CSV: $ID - Categoria: $CATEGORIA - Titolo Attività: $TITOLO - Descrizione: $DESCRIZIONE - Ruolo: $RUOLO"

    # Esecuzione della Gemini CLI tramite pipe.
    # Redirigiamo l'output per nascondere i log verbali e mostrare solo un feedback pulito.
    echo "Attendere, generazione in corso per l'attività '$TITOLO'..."
    echo "$USER_PROMPT" | GEMINI_SYSTEM_MD="$AGENT_FILE" gemini -p "Genera la blueprint basandoti sui dati in input." --yolo --output-format text > /dev/null 2>&1
    
    # Cerchiamo il file appena generato e stampiamo solo i titoli delle fasi
    GENERATED_FILE=$(ls Blueprint/${ID}_blueprint_*.md 2>/dev/null | head -n 1)
    if [ -f "$GENERATED_FILE" ]; then
        echo "✅ Completato ID [$ID]. File salvato in: $GENERATED_FILE"
        echo "Fasi identificate:"
        grep "^### Fase" "$GENERATED_FILE" | sed 's/^/  /'
    else
        echo "⚠️ Attenzione: Elaborazione terminata ma file per ID [$ID] non trovato con il nome atteso."
    fi
done

echo "---------------------------------------------------------"
echo "Tutte le elaborazioni richieste sono terminate. Controlla la cartella Blueprint/."
