# Blueprint GenAI: Efficentamento del "Design Alta Affidabilità (HA)"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design
**Titolo:** Design Alta Affidabilità (HA)
**Ruolo:** Infrastructure Architect
**Obiettivo Originale (da CSV):** Progettazione di sistemi resilienti in grado di garantire la continuità operativa. Include la configurazione di cluster attivo-attivo, bilanciatori di carico L4/L7, auto-scaling group e ridondanza geografica multi-region sui cloud provider.
**Obiettivo GenAI:** Automatizzare la raccolta dei requisiti di business (RTO/RPO) e la generazione immediata di un documento di design architetturale (High-Level Design) per soluzioni in Alta Affidabilità (cluster attivo-attivo, Load Balancing L4/L7, Auto-Scaling e Multi-Region), garantendo l'aderenza alle best practice del cloud provider scelto senza sconfinare nell'implementazione di codice IaC.

## 2. Fasi del Processo Efficentato

### Fase 1: Raccolta Requisiti e Generazione HA Design Pattern
L'Infrastructure Architect interagisce con un Chatbot direttamente integrato in Microsoft Teams, fornendo i parametri e i vincoli base (es. target RPO/RTO, Cloud Provider, tipologia di workload). L'AI analizza i requisiti e genera istantaneamente una proposta architetturale strutturata.
*   **Tool Principale Consigliato:** Microsoft Teams (Chatbot UI) tramite Copilot Studio
*   **Alternative:** 1. Accenture Amethyst, 2. ChatGPT Agent (Enterprise)
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro (eccellente nel ragionamento architetturale e nella strutturazione di documenti tecnici complessi) o OpenAI GPT-5.4
*   **Modalità di Utilizzo:** Il tool viene richiamato come assistente conversazionale nel canale Teams o in chat privata.
    **Bozza del System Prompt per il Bot:**
    ```text
    Sei un Expert Cloud Infrastructure Architect. Il tuo compito è progettare architetture in Alta Affidabilità (HA).
    Quando l'utente fornisce i parametri di RPO, RTO, Cloud Provider (es. AWS, Azure, GCP) e tipo di applicazione, devi generare un High-Level Design (HLD) strutturato in formato Markdown che includa:
    1. Scelta dei Load Balancer (L4/L7) e relativa giustificazione architetturale.
    2. Configurazione dell'Auto-Scaling Group.
    3. Strategia di cluster attivo-attivo e meccanismi di replica dati Multi-Region/Multi-AZ.
    4. Elenco dei servizi Cloud Nativi suggeriti per garantire la continuità operativa in base al provider indicato.
    Rispondi sempre in modo chiaro, tecnico e pronto per essere incollato in un documento di progetto formale.
    ```
*   **Azione Umana Richiesta:** L'Infrastructure Architect deve leggere la proposta, validare la coerenza tecnica, richiedere eventuali aggiustamenti iterativi via chat (es. "ottimizza per il costo, passando a una strategia Multi-AZ invece che Multi-Region") e approvare il design.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore (analisi documentazione, definizione pattern, stesura e formattazione dell'HLD)
    *   *Tempo To-Be (GenAI):* 30 minuti
    *   *Risparmio %:* 91%
    *   *Motivazione:* L'AI abbatte i tempi di stesura del documento e di ricerca documentale per i singoli servizi cloud, fornendo immediatamente un template solido e argomentato basato sulle best practice del provider.

## 3. Descrizione del Flusso Logico
Il flusso adotta un'architettura **Single-Agent** conversazionale, ideale per mantenere il processo lineare e favorire un'adozione rapida. L'Infrastructure Architect apre Microsoft Teams, richiama il bot e digita i requisiti architetturali di alto livello. L'agente elabora l'input, seleziona i pattern cloud adeguati (L4/L7, cluster, repliche) e restituisce una bozza di documento HLD in Markdown. Attraverso l'approccio "Human-in-the-loop", l'architetto conversa con il bot per perfezionare la proposta (aggiungendo vincoli di costo o performance). Una volta raggiunto il design ideale, il documento viene copiato e integrato formalmente, o opzionalmente salvato in automatico su una directory SharePoint aziendale configurata come repository di progetto.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    A[Infrastructure Architect] -->|Chat/Input Requisiti| B[Microsoft Teams Bot UI]
    B -->|API Request| C[Copilot Studio / AI Orchestrator]
    C -->|Prompt & Context| D[LLM: Gemini 3.1 Pro / GPT-5.4]
    D -->|Generazione HA Design HLD| C
    C -->|Risposta Formattata Markdown| B
    C -.->|Salvataggio opzionale| E[SharePoint aziendale Repository]
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    S[Inizio] --> P[Inserimento requisiti RPO/RTO e Cloud su Teams]
    P --> AI[Generazione Design Architetturale HA]
    AI --> R[Revisione da parte dell'Architect]
    R --> D{Design Approvato?}
    D -- No --> Mod[Richiesta Modifiche e Ottimizzazioni in Chat]
    Mod --> AI
    D -- Sì --> F[Esportazione HLD Definitivo]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant IA as Infrastructure Architect
    participant Teams as Microsoft Teams
    participant LLM as AI Agent (Gemini/GPT)
    
    IA->>Teams: "Crea design HA per app web su AWS, RTO 1h, RPO 15m"
    Teams->>LLM: Invia System Prompt + User Query
    LLM-->>Teams: Restituisce HLD (ALB, ASG, Multi-Region RDS)
    Teams-->>IA: Mostra Design in chat
    IA->>Teams: "Ottimizza i costi riducendo a singola Region ma Multi-AZ"
    Teams->>LLM: Invia feedback di raffinamento
    LLM-->>Teams: Restituisce HLD aggiornato
    Teams-->>IA: Mostra Design finale
    IA->>IA: Approva, copia o salva il documento
```

## 5. Guida all'Implementazione Tecnica
### Prerequisiti
- Licenza Microsoft 365 con accesso a Microsoft Copilot Studio.
- Permessi di amministrazione per la pubblicazione di bot all'interno del tenant Microsoft Teams aziendale.

### Step 1: Configurazione del Copilot Studio
1. Accedere a Microsoft Copilot Studio (copilotstudio.microsoft.com).
2. Creare un nuovo Copilot nominandolo "HA Architecture Assistant".
3. Andare nella sezione dedicata alle "System Instructions" (o Generative AI settings).
4. Incollare il System Prompt definito nella Fase 1 per istruire il modello sul suo ruolo di Infrastructure Architect.

### Step 2: Connessione Base Dati (Opzionale)
1. Per rendere le risposte più aderenti agli standard aziendali, aggiungere una "Knowledge Connection" puntando a un sito SharePoint che contiene vecchi documenti di design approvati, così che il bot ne assimili struttura e stile.

### Step 3: Integrazione e Pubblicazione su Microsoft Teams
1. Nella dashboard di Copilot Studio, navigare sulla scheda "Publish".
2. Cliccare su "Channels" e selezionare "Microsoft Teams".
3. Completare la procedura di "Turn on Teams".
4. Cliccare su "Submit for admin approval" (se richiesto dal tenant) o direttamente su "Open in Teams" per testare il bot in chat privata o aggiungerlo al canale dedicato al team Architecture.

## 6. Rischi e Mitigazioni
- **Rischio 1:** Allucinazione tecnica, l'AI potrebbe suggerire combinazioni di servizi (es. specifici Load Balancer con determinati tipi di cluster) non ottimali o deprecati dal cloud provider. -> **Mitigazione:** Obbligo procedurale di revisione umana (Human-in-the-loop); l'architetto ha sempre l'ultima parola sul design prima che passi alla fase di implementazione IaC. L'uso di LLM aggiornati (marzo 2026) minimizza l'impiego di servizi deprecati.
- **Rischio 2:** Data Privacy e fuga di informazioni sensibili se l'architetto inserisce indirizzi IP, nomi host reali o dati critici dell'infrastruttura cliente nel prompt. -> **Mitigazione:** Implementazione di una policy di "Astrazione del Dato" (inserire solo ruoli generici nel prompt, es. "Database Server" invece di "DB-PROD-CUST1") e utilizzo dell'ambiente Copilot for Microsoft 365 Enterprise, che garantisce la non ritenzione dei dati di prompt per l'addestramento dei modelli.
