# Blueprint GenAI: Efficentamento del "Design Disaster Recovery (DR)"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design
**Titolo:** Design Disaster Recovery (DR)
**Ruolo:** Disaster Recovery Specialist
**Obiettivo Originale (da CSV):** Definizione delle strategie e delle tempistiche (RTO e RPO) per il ripristino dei servizi IT a seguito di eventi disastrosi. Include la progettazione di siti secondari in cold/warm standby e la stesura delle procedure di failover e failback.
**Obiettivo GenAI:** Automatizzare l'analisi dei requisiti di continuità operativa per generare scenari di Disaster Recovery personalizzati, calcolare RTO/RPO ottimali in base alla criticità e produrre bozze dettagliate di procedure di failover/failback pronte per la revisione umana.

## 2. Fasi del Processo Efficentato

### Fase 1: Analisi Requisiti e Definizione Strategia (RTO/RPO)
L'AI analizza il catalogo dei servizi IT e le dipendenze applicative per suggerire i parametri di recovery e la strategia (Cold/Warm/Hot Standby) più idonea per ogni classe di servizio.
*   **Tool Principale Consigliato:** Accenture Amethyst (per l'analisi sicura di documenti interni e policy).
*   **Alternative:** 1. ChatGPT Agent (Enterprise), 2. Google Gemini (via Vertex AI).
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4.
*   **Modalità di Utilizzo:** Caricamento del Business Impact Analysis (BIA) e del catalogo servizi su Amethyst. L'LLM estrae le dipendenze critiche e propone una tabella di classificazione DR.
    *   **Bozza Prompt:** *"Analizza il documento BIA allegato e identifica le applicazioni con priorità 'Critical'. Per ognuna, suggerisci un target RTO < 4h e RPO < 1h, motivando la scelta in base alle dipendenze infrastrutturali rilevate. Proponi se adottare un modello Warm Standby o Pilot Light."*
*   **Azione Umana Richiesta:** Validazione della classificazione dei servizi e approvazione dei target RTO/RPO proposti.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 8 ore (riunioni e analisi documenti).
    *   *Tempo To-Be (GenAI):* 30 minuti.
    *   *Risparmio %:* 94%
    *   *Motivazione:* L'AI correla istantaneamente moli enormi di dipendenze applicative che richiederebbero ore di navigazione tra Excel e CMDB.

### Fase 2: Progettazione Infrastrutturale Sito Secondario
Generazione del disegno logico e delle specifiche tecniche per il sito di DR in base alla strategia scelta.
*   **Tool Principale Consigliato:** gemini-cli (per generazione rapida di specifiche tecniche partendo da export di configurazione).
*   **Alternative:** 1. visualstudio + copilot (per schemi IaC), 2. Claude-code.
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro.
*   **Modalità di Utilizzo:** Scripting via terminale che invia le specifiche del sito primario all'LLM e riceve in output l'elenco delle risorse necessarie per il sito secondario (es. taglie istanze ridotte per Warm Standby).
*   **Azione Umana Richiesta:** Verifica della compatibilità hardware/cloud tra sito primario e secondario.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 12 ore.
    *   *Tempo To-Be (GenAI):* 45 minuti.
    *   *Risparmio %:* 93%
    *   *Motivazione:* L'AI effettua il dimensionamento automatico delle risorse speculari applicando i pattern di risparmio definiti per il DR.

### Fase 3: Stesura Procedure Failover e Failback (Runbook)
Creazione dei documenti procedurali passo-passo (Step-by-step Runbook) per l'attivazione del DR e il successivo ritorno alla normalità.
*   **Tool Principale Consigliato:** Copilot Studio (pubblicato su Microsoft Teams).
*   **Alternative:** 1. n8n (per workflow di generazione doc), 2. ChatGPT Agent.
*   **Modelli LLM Suggeriti:** Anthropic Claude Sonnet 4.6.
*   **Modalità di Utilizzo:** Bot su Teams che guida il DR Specialist con domande mirate (es. "Quale tool di replica usi? Zerto o SRM?"). Al termine, il bot genera un file Markdown con la procedura completa.
*   **Azione Umana Richiesta:** Validazione tecnica e test (DR Drill) per confermare la correttezza dei comandi suggeriti.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 16 ore (stesura di manuali complessi).
    *   *Tempo To-Be (GenAI):* 1 ora (interazione con bot + check).
    *   *Risparmio %:* 94%
    *   *Motivazione:* L'AI redige la documentazione tecnica con un linguaggio standardizzato e coerente, evitando omissioni comuni.

## 3. Descrizione del Flusso Logico
Il processo è gestito tramite un approccio **Single-Agent** orchestrato via **Microsoft Teams**. L'agente (DR Architect Bot) funge da orchestratore: attinge ai documenti di architettura su SharePoint (RAG), propone la strategia, e dopo l'approvazione umana, genera i dettagli tecnici del sito secondario e i relativi runbook di emergenza. Il flusso è lineare: Input (Dati Primari) -> Analisi GenAI -> Validazione Umana -> Generazione Documentazione -> Approvazione Finale.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
  User[DR Specialist] -- Interagisce via Teams --> TeamsBot[Copilot Studio Bot]
  TeamsBot -- Query RAG --> SharePoint[SharePoint: BIA & Architettura]
  TeamsBot -- Richiesta Generazione --> LLM[Gemini 3.1 Pro / GPT-5.4]
  LLM -- Produce --> DRP[Disaster Recovery Plan .md]
  DRP -- Archiviato in --> Repo[Repository Procedure DR]
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    Start([Inizio Progettazione DR]) --> Ingest[Analisi BIA via RAG]
    Ingest --> Suggest[Proposta RTO/RPO e Standby Mode]
    Suggest --> Review{Approvazione Specialist?}
    Review -- NO --> Adjust[Modifica parametri Manualmente]
    Adjust --> Suggest
    Review -- SI --> Design[Generazione Specifiche Sito Secondario]
    Design --> Runbook[Generazione Procedure Failover/Failback]
    Runbook --> End([DRP Pronto per Drill])
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    participant S as Specialist
    participant B as Teams Bot (GenAI)
    participant R as RAG (SharePoint)
    participant L as LLM

    S->>B: Avvia nuovo Design DR per "App_Pagamenti"
    B->>R: Recupera BIA e Diagrammi Architetturali
    R-->>B: Dati recuperati
    B->>L: Genera proposta RTO/RPO e strategia
    L-->>B: Proposta: Warm Standby, RTO 2h, RPO 15m
    B->>S: Mostra proposta e chiede conferma
    S->>B: Conferma e richiedi Runbook
    B->>L: Scrivi procedura failover dettagliata
    L-->>B: Markdown Runbook generato
    B->>S: Consegna documento finale
```

## 5. Guida all'Implementazione Tecnica
### Prerequisiti
- Licenza Copilot Studio o accesso a n8n.
- Accesso API a Google Gemini o OpenAI (via Azure/AWS/Direct).
- Documentazione BIA e HLD archiviata su SharePoint.

### Step 1: Configurazione Knowledge Base
Caricare le policy di Disaster Recovery aziendali e i template dei Runbook in una cartella SharePoint dedicata. Configurare Copilot Studio per utilizzare questa cartella come sorgente per le risposte generative (RAG).

### Step 2: Definizione System Prompt del Bot
Configurare il bot con il seguente System Prompt:
> "Sei un Esperto di Disaster Recovery. Il tuo compito è assistere nella creazione di Piani di Disaster Recovery (DRP). Usa la documentazione su SharePoint per identificare le criticità. Suggerisci sempre strategie basate sui costi (Cold/Warm/Hot). Genera procedure di failover usando un formato markdown chiaro, includendo i comandi CLI se necessari (es. AWS, Azure, VMware)."

### Step 3: Integrazione e Output
Configurare un'azione (Power Automate o n8n) che, al comando "Genera Documento", prenda l'output dell'LLM e crei un file .md su Teams o SharePoint per la revisione finale.

## 6. Rischi e Mitigazioni
- **Rischio: Comandi CLI errati nelle procedure** -> **Mitigazione:** Obbligo di revisione tecnica da parte del DR Specialist e test in ambiente di staging prima dell'approvazione del runbook.
- **Rischio: Allucinazione su dipendenze critiche** -> **Mitigazione:** Il bot deve citare la fonte (documento SharePoint) per ogni dipendenza identificata.
- **Rischio: Esposizione dati sensibili** -> **Mitigazione:** Utilizzo di istanze LLM Enterprise con protezione dei dati (nessun addestramento sui dati utente).
