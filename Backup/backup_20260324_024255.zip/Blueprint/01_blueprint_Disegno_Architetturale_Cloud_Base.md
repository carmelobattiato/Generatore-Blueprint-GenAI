# Blueprint GenAI: Efficentamento del "Disegno Architetturale Cloud Base"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design
**Titolo:** Disegno Architetturale Cloud Base
**Ruolo:** Cloud Architect
**Obiettivo Originale (da CSV):** Progettazione dell'architettura di base per ambienti cloud (pubblici, privati o ibridi). Include la definizione di reti virtuali, subnetting, regole di routing e componenti di base necessari per ospitare le applicazioni aziendali, assicurando scalabilità e sicurezza fin dal principio.
**Obiettivo GenAI:** Automatizzare la creazione del High-Level Design (HLD) e della topologia di rete (diagramma) a partire da un set di requisiti testuali o intervista guidata, riducendo drasticamente il tempo di drafting iniziale.

## 2. Fasi del Processo Efficentato

### Fase 1: Raccolta Requisiti e Intervista Guidata
L'architetto interagisce con un bot su Microsoft Teams che pone domande strutturate per estrarre i parametri necessari (es. Cloud Provider, numero di zone, range IP desiderato, compliance richieste).
*   **Tool Principale Consigliato:** Copilot Studio (pubblicato su Microsoft Teams)
*   **Alternative:** 1. Accenture Amethyst (Chat), 2. ChatGPT Agent (Enterprise)
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4
*   **Modalità di Utilizzo:** Configurazione di un Copilot con un System Prompt specifico che agisce come "Requirement Analyst". Il bot salva i dati in un file JSON temporaneo su SharePoint.
    *   **Bozza System Prompt:**
        ```text
        Sei un Cloud Architecture Analyst. Il tuo compito è intervistare l'utente per raccogliere:
        1. Cloud Provider (AWS/Azure/GCP).
        2. Numero di Tier applicativi (es. Web, App, DB).
        3. Requisiti di connettività (VPN, Direct Connect, Internet-facing).
        4. Stima del numero di risorse per dimensionare il subnetting.
        Sii conciso e professionale. Una volta raccolti i dati, conferma il riepilogo.
        ```
*   **Azione Umana Richiesta:** Validazione finale del riepilogo dei requisiti in chat.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 2 ore (meeting e stesura appunti)
    *   *Tempo To-Be (GenAI):* 15 minuti
    *   *Risparmio %:* 87.5%
    *   *Motivazione:* Eliminazione della trascrizione manuale e standardizzazione immediata dei requisiti.

### Fase 2: Generazione Topologia e HLD
I dati raccolti vengono inviati a un workflow che genera la struttura del documento HLD e il codice Mermaid per il diagramma architetturale.
*   **Tool Principale Consigliato:** n8n (Orchestratore) + Gemini 3.1 Pro
*   **Alternative:** 1. Google Antigravity, 2. gemini-cli
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro (ottimale per ragionamento strutturale e generazione codice Mermaid)
*   **Modalità di Utilizzo:** Un workflow n8n attivato da un webhook (da Copilot Studio) invia il JSON a Gemini 3.1 Pro con un prompt ingegnerizzato per produrre un documento Markdown (HLD) e un blocco Mermaid.js.
    *   **Bozza Prompt di Generazione:**
        ```text
        Dati i seguenti requisiti: {{input_json}}, genera un'architettura cloud sicura.
        Produci:
        1. Uno schema delle Subnet (Public/Private) con relativi CIDR.
        2. Regole di routing principali.
        3. Un diagramma Mermaid.js di tipo 'graph TD'.
        Usa i principi del Well-Architected Framework del provider scelto.
        ```
*   **Azione Umana Richiesta:** Revisione tecnica del design generato.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore (disegno su Visio/Draw.io + scrittura doc)
    *   *Tempo To-Be (GenAI):* 5 minuti
    *   *Risparmio %:* 98.6%
    *   *Motivazione:* La generazione istantanea di diagrammi testuali e bozze documentali abbatte i tempi di "pagina bianca".

### Fase 3: Visualizzazione e Archiviazione
Visualizzazione dell'output in una dashboard dedicata e salvataggio del documento finale su SharePoint.
*   **Tool Principale Consigliato:** AI-Studio Google (per Build WebApp Dashboard)
*   **Alternative:** 1. Microsoft Teams (scheda SharePoint), 2. n8n (invio mail con allegato)
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro
*   **Modalità di Utilizzo:** Utilizzo della funzione "Build" di AI-Studio per generare una semplice WebApp in React che renderizza il codice Mermaid generato e permette di scaricare l'HLD in formato PDF/Markdown.
*   **Azione Umana Richiesta:** Approvazione finale e "Save to SharePoint".
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 1 ora (formattazione e upload)
    *   *Tempo To-Be (GenAI):* 2 minuti
    *   *Risparmio %:* 96.6%
    *   *Motivazione:* Automazione completa della pipeline di pubblicazione.

## 3. Descrizione del Flusso Logico
Il processo inizia su **Microsoft Teams**, dove il Cloud Architect avvia una conversazione con il bot di acquisizione. Una volta confermati i requisiti, i dati fluiscono verso **n8n**, che funge da "cervello" dell'automazione, richiamando **Gemini 3.1 Pro** per il ragionamento architetturale. L'output (testo HLD + diagramma Mermaid) viene poi visualizzato in una **WebApp custom** creata rapidamente tramite AI-Studio per una revisione visuale immediata. Il flusso si conclude con il salvataggio automatico su **SharePoint**.

**Architettura Agentica:** Approccio **Single-Agent** (Architetto Virtuale) per semplicità di gestione, poiché il task è lineare e non richiede negoziazioni tra agenti diversi.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
  User((Cloud Architect)) --> Teams[Microsoft Teams UI]
  Teams --> CS[Copilot Studio Bot]
  CS --> SP_Data[(SharePoint / JSON)]
  CS --> N8N[n8n Workflow]
  N8N --> Gemini[Gemini 3.1 Pro API]
  Gemini --> N8N
  N8N --> AIS[AI-Studio Dashboard / React]
  AIS --> FinalDoc[Final HLD Document]
  FinalDoc --> SP_Archive[(SharePoint Archive)]
```

### 4.2 Process Diagram
```mermaid
flowchart TD
  Start(Inizio Richiesta) --> Interview[Intervista guidata su Teams]
  Interview --> Confirm{Requisiti OK?}
  Confirm -- No --> Interview
  Confirm -- Si --> GenDraft[Generazione HLD & Diagramma Mermaid]
  GenDraft --> Review[Review su WebApp Dashboard]
  Review --> Edit{Necessarie Modifiche?}
  Edit -- Si --> GenDraft
  Edit -- No --> Save[Salvataggio su SharePoint]
  Save --> End(Fine)
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
  participant A as Cloud Architect
  participant T as Teams / Copilot Bot
  participant N as n8n Orchestrator
  participant G as Gemini 3.1 Pro
  participant S as SharePoint

  A->>T: Inizia "Nuovo Design"
  T->>A: Domande sui requisiti (Provider, Subnet, ecc.)
  A->>T: Fornisce risposte
  T->>N: Invia Payload JSON
  N->>G: Richiesta generazione HLD + Mermaid
  G->>N: Ritorna Testo MD e Codice Diagramma
  N->>A: Notifica completamento su Teams con link Dashboard
  A->>S: Conferma e Salva
```

## 5. Guida all'Implementazione Tecnica
### Prerequisiti
- Licenza Microsoft Copilot Studio e accesso a Teams.
- Istanza n8n (Self-hosted o Cloud).
- API Key per Google Gemini (via Google AI Studio).
- Accesso in scrittura a una cartella SharePoint tramite Microsoft Graph API (su n8n).

### Step 1: Configurazione Copilot Studio
1. Creare un nuovo bot in Copilot Studio nominato "Cloud Architect Assistant".
2. Configurare i "Topics" per l'intervista guidata, utilizzando le variabili per memorizzare le risposte.
3. Aggiungere un nodo "Call an action" che attiva un webhook di n8n passando il JSON delle variabili.

### Step 2: Workflow n8n
1. Nodo **Webhook**: Riceve i dati da Teams.
2. Nodo **Google Gemini**: Utilizzare il modello `gemini-3.1-pro`. Inserire il System Prompt per la generazione del design (vedi Fase 2).
3. Nodo **HTTP Request (SharePoint)**: Configurare l'upload del file Markdown risultante.

### Step 3: Visualizzazione (AI-Studio)
1. In Google AI Studio, usare la funzione "Build" per creare una WebApp che accetti in input il codice Mermaid e lo renderizzi usando la libreria `mermaid.js`.
2. Integrare il link di questa WebApp nel messaggio di risposta di n8n su Teams.

## 6. Rischi e Mitigazioni
- **Rischio 1: Allucinazioni nei CIDR** (es. sovrapposizione di subnet) -> **Mitigazione:** Inserire nel prompt una logica di validazione IP e richiedere all'utente di confermare i range proposti.
- **Rischio 2: Sicurezza dei dati** -> **Mitigazione:** Utilizzare l'ambiente Enterprise di Microsoft e API Key gestite in modo sicuro (Secret Manager) in n8n.
- **Rischio 3: Compliance non rispettata** -> **Mitigazione:** Il Cloud Architect (Human-in-the-loop) deve obbligatoriamente validare l'output prima dell'uso in produzione.
