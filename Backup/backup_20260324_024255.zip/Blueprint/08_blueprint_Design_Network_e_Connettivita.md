# Blueprint GenAI: Efficentamento del "Design Network e Connettività"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design
**Titolo:** Design Network e Connettività
**Ruolo:** Network Architect
**Obiettivo Originale (da CSV):** Progettazione dell'infrastruttura di rete logica e fisica ibrida. Include la definizione di topologie Hub&Spoke, VPN Site-to-Site, connessioni dedicate (es. AWS Direct Connect/Azure ExpressRoute), firewalling di perimetro e segmentazione interna Zero Trust.
**Obiettivo GenAI:** Automatizzare la generazione di schemi di rete logici (High Level Design - HLD), il calcolo degli indirizzamenti CIDR e la definizione delle policy di segmentazione Zero Trust a partire dai requisiti di business e compliance, utilizzando un'interfaccia conversazionale su Microsoft Teams.

## 2. Fasi del Processo Efficentato

### Fase 1: Ingestion dei Requisiti e Analisi Topologica
L'utente interagisce con un bot su Microsoft Teams fornendo i parametri di base (numero di VPC/VNet, regioni Cloud, sedi on-premise, requisiti di banda). Il sistema analizza i documenti di compliance aziendale su SharePoint per garantire che la topologia rispetti gli standard (es. Hub&Spoke obbligatorio).
*   **Tool Principale Consigliato:** `copilot studio` (interfaccia Teams) + `accenture ametyst` (analisi documenti)
*   **Alternative:** 1. ChatGPT Agent (Enterprise), 2. n8n (per orchestratore workflow)
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro (per ragionamento multimodale su schemi esistenti)
*   **Modalità di Utilizzo:** Configurazione di un Agent su Teams che interroga il repository SharePoint.
    *   **Bozza Prompt Bot:** "Sei un Senior Network Architect AI. Ricevi in input i requisiti di connettività ibrida e, consultando il manuale 'Network Security Standard V2.pdf' su SharePoint, proponi una topologia Hub&Spoke che includa il dimensionamento delle subnet e la strategia di routing tra Cloud e On-Premise."
*   **Azione Umana Richiesta:** Validazione dei parametri di input e conferma del perimetro di rete proposto.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore (analisi standard e bozza iniziale)
    *   *Tempo To-Be (GenAI):* 15 minuti
    *   *Risparmio %:* 96%
    *   *Motivazione:* L'AI recupera istantaneamente gli standard di compliance e genera una bozza coerente senza errori di calcolo CIDR.

### Fase 2: Generazione Design Logico e Diagrammi (HLD)
L'AI genera il codice Mermaid.js per la visualizzazione della topologia e produce un documento HLD (High Level Design) strutturato, includendo tabelle di routing e regole di firewalling di alto livello.
*   **Tool Principale Consigliato:** `visualstudio + copilot` (per raffinamento logica) + `gemini-cli` (per generazione bulk documentazione)
*   **Alternative:** 1. Claude-code, 2. AI-Studio Google
*   **Modelli LLM Suggeriti:** Anthropic Claude 4.6 Sonnet (eccellente in diagrammi e precisione documentale)
*   **Modalità di Utilizzo:** Scripting via `gemini-cli` che trasforma i requisiti validati nella Fase 1 in un file Markdown completo di diagrammi Mermaid.
    *   **Esempio Prompt HLD:** "Genera un documento HLD per una rete ibrida AWS-Azure. Includi un diagramma Mermaid `graph TD` che mostri la Transit Gateway, le VPC Spoke e la connessione Direct Connect. Definisci una tabella con 4 subnet /24 per VPC seguendo il principio Zero Trust (segmentazione Web, App, DB, MGMT)."
*   **Azione Umana Richiesta:** Revisione tecnica del diagramma e approvazione della segmentazione proposta.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 8 ore (disegno manuale e scrittura doc)
    *   *Tempo To-Be (GenAI):* 20 minuti
    *   *Risparmio %:* 95%
    *   *Motivazione:* L'automazione della grafica (Mermaid) e delle tabelle di routing elimina il lavoro di data-entry e disegno manuale su software CAD/Visio.

### Fase 3: Definizione Policy Zero Trust e Firewalling
Generazione di un set di regole firewall (NSG, Security Groups, Palo Alto/Fortinet policies) basate sul principio del "least privilege" identificato nell'architettura.
*   **Tool Principale Consigliato:** `visualstudio + copilot`
*   **Alternative:** 1. OpenAI Codex, 2. OpenClaw (per dati sensibili di rete)
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4 (per logica di policy granulare)
*   **Modalità di Utilizzo:** Chat interattiva in VS Code per generare i manifesti delle regole firewall a partire dall'HLD approvato.
*   **Azione Umana Richiesta:** Il Network Security Engineer deve validare le porte e i protocolli aperti prima dell'applicazione.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 4 ore (definizione tabelle ACL)
    *   *Tempo To-Be (GenAI):* 10 minuti
    *   *Risparmio %:* 95%
    *   *Motivazione:* L'AI mappa automaticamente i flussi tra le subnet definite nella Fase 2 traducendoli in regole di sicurezza coerenti.

## 3. Descrizione del Flusso Logico
Il processo è **Single-Agent** per le fasi di design iniziale, orchestrato tramite **Microsoft Teams**. L'utente avvia la sessione tramite un comando `/new-network-design`. Il bot (Copilot Studio) raccoglie i dati, interroga SharePoint tramite RAG (Retrieval-Augmented Generation) per gli standard aziendali e genera una proposta. Una volta approvata, il flusso passa a un worker secondario (tramite `n8n` o `gemini-cli`) che produce il documento tecnico finale e i diagrammi. L'interazione umana è fondamentale tra la Fase 2 e la Fase 3 per garantire che la segmentazione Zero Trust non blocchi servizi critici.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
  User((Network Architect)) -->|Input Requisiti| Teams[Microsoft Teams Bot]
  Teams -->|Query| CS[Copilot Studio]
  CS -->|RAG| SP[SharePoint: Standard Rete]
  CS -->|Prompt| LLM[Gemini 3.1 Pro API]
  LLM -->|Genera HLD & Mermaid| Teams
  LLM -->|Output MD| Repo[Git/SharePoint Storage]
```

### 4.2 Process Diagram
```mermaid
flowchart TD
  Start[Inizio Progettazione] --> Ingest[Raccolta Parametri su Teams]
  Ingest --> Check[Analisi Standard Aziendali - RAG]
  Check --> GenTopology[Generazione Proposta Topologica]
  GenTopology --> Review{Approvazione Architetto?}
  Review -- No --> Edit[Modifica Parametri]
  Edit --> GenTopology
  Review -- Si --> GenDocs[Generazione HLD & Policy Zero Trust]
  GenDocs --> End[Consegna Blueprint Esecutiva]
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
  participant Architect as Network Architect
  participant Bot as Teams Bot (Copilot Studio)
  participant AI as Gemini 3.1 Pro
  participant SP as SharePoint (Docs)

  Architect->>Bot: Avvia Design Rete (/new-network)
  Bot->>Architect: Chiede parametri (Cloud, Sedi, Banda)
  Architect->>Bot: Fornisce dati AWS/Azure e Sede Milano
  Bot->>SP: Cerca standard VPN/Firewall
  SP-->>Bot: Restituisce policy sicurezza
  Bot->>AI: Genera topologia Hub&Spoke + CIDR + Mermaid
  AI-->>Bot: Markdown con Diagramma e Tabelle
  Bot->>Architect: Mostra Design Preliminare
  Architect->>Bot: Approva e richiede Policy Zero Trust
  Bot->>AI: Genera Regole Firewall basate su segmentazione
  AI-->>Bot: Lista Regole (JSON/MD)
  Bot->>Architect: Consegna HLD Finale
```

## 5. Guida all'Implementazione Tecnica

### Prerequisiti
- Licenza **Microsoft Copilot Studio** e accesso a Teams.
- Repository **SharePoint** contenente i PDF/Docx con gli standard di rete aziendali.
- API Key per **Google Gemini API** (per l'uso via CLI o n8n).

### Step 1: Configurazione Copilot Studio
1.  Accedi a Copilot Studio e crea un nuovo bot chiamato "Network Design Assistant".
2.  Configura l'**Infrastruttura Dati**: collega il bot alla cartella SharePoint "Network-Standards".
3.  Definisci il **System Prompt**: "Sei un esperto di reti ibride. Usa solo gli standard presenti nei documenti caricati. Se un requisito viola gli standard (es. uso di VPN invece di Direct Connect per carichi >1Gbps), segnalalo."

### Step 2: Integrazione Canale Teams
1.  Pubblica il bot sul canale Microsoft Teams del team "Technology & Architecture".
2.  Configura un'azione di "Knowledge Retrieval" affinché il bot possa rispondere basandosi sui documenti tecnici.

### Step 3: Generazione Automatica HLD (Markdown)
1.  Utilizza un workflow `n8n` che riceve il trigger da Teams quando il design è approvato.
2.  Il nodo "AI Agent" (Gemini 3.1) formatta i dati in Markdown.
3.  Il file viene salvato automaticamente su SharePoint e inviato via mail all'architetto.

## 6. Rischi e Mitigazioni
- **Rischio 1: Sovrapposizione CIDR (Overlapping):** L'AI potrebbe suggerire range già in uso. -> **Mitigazione:** Integrare un tool MCP che interroghi l'IPAM (IP Address Management) aziendale via API prima della generazione.
- **Rischio 2: Allucinazioni su porte firewall:** Suggerimento di porte errate per protocolli standard. -> **Mitigazione:** Validazione obbligatoria (Human-in-the-loop) tramite checklist generata dall'AI stessa a fine processo.
