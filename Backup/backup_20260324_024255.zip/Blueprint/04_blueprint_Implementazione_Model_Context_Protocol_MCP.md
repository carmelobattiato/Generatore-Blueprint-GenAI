# Blueprint GenAI: Efficentamento del "Implementazione Model Context Protocol (MCP)"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design
**Titolo:** Implementazione Model Context Protocol (MCP)
**Ruolo:** Security Engineer
**Obiettivo Originale (da CSV):** Progettazione e rilascio di server MCP sicuri all'interno della rete aziendale per consentire agli agenti LLM di interrogare in sicurezza database relazionali legacy, API interne e sistemi di ticketing (es. Jira/ServiceNow) senza esporre credenziali.
**Obiettivo GenAI:** Automatizzare la generazione, la configurazione di sicurezza e il deployment del codice boilerplate per un Server MCP, permettendo l'esposizione sicura e standardizzata di API interne e DB legacy verso gli agenti LLM aziendali.

## 2. Fasi del Processo Efficentato

### Fase 1: Scaffolding e Codifica del Server MCP
La GenAI genera istantaneamente la struttura base del server MCP (es. in Python o TypeScript utilizzando gli SDK ufficiali), definendo i tool esposti (es. `query_jira`, `fetch_legacy_db`) e le logiche di connessione standardizzate.
*   **Tool Principale Consigliato:** `visualstudio + copilot`
*   **Alternative:** 1. `claude-code`, 2. `OpenAI Codex`
*   **Modelli LLM Suggeriti:** Anthropic Claude Sonnet 4.6 (ideale per generazione di codice specializzato e integrazioni di protocollo) o Google Gemini 3.1 Pro.
*   **Modalità di Utilizzo:** Utilizzo di GitHub Copilot Chat integrato in VS Code per richiedere la generazione del server. Esempio di prompt per Copilot:
    ```markdown
    Genera un server MCP in Python usando la libreria ufficiale `mcp`. Esponi un tool chiamato `get_jira_ticket` che accetta un `ticket_id`. Il server deve leggere le credenziali (URL e API Key) da variabili d'ambiente in modo sicuro e usare la libreria `requests` per interrogare l'API di Jira. Includi logging strutturato e gestione rigorosa degli errori per evitare blocchi.
    ```
    *Integrazione:* Il codice prodotto viene salvato localmente per poi essere pushato nei repository aziendali (es. GitHub/Bitbucket).
*   **Azione Umana Richiesta:** Il Security Engineer deve ispezionare il codice generato per assicurarsi che non ci siano vulnerabilità di injection (es. SQL injection nei tool del DB) e che il logging non esponga i token.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 8 ore (studio documentazione MCP, scrittura boilerplate, test di connessione).
    *   *Tempo To-Be (GenAI):* 30 minuti.
    *   *Risparmio %:* 93%
    *   *Motivazione:* Copilot conosce la specifica MCP ed è in grado di fornire codice funzionante, tipizzato e idiomatico al primo colpo, riducendo drasticamente il tempo di setup.

### Fase 2: Configurazione della Sicurezza e Gestione Secrets
Creazione di script di automazione per il deployment in cui le credenziali (Jira/DB) non sono hardcoded, ma iniettate a runtime tramite un Secret Manager aziendale (es. Azure Key Vault, AWS Secrets Manager).
*   **Tool Principale Consigliato:** `gemini-cli`
*   **Alternative:** 1. `visualstudio + copilot`, 2. `n8n`
*   **Modelli LLM Suggeriti:** Google Gemini 3.1 Pro (eccellente per scripting bash e configurazioni infrastrutturali).
*   **Modalità di Utilizzo:** Richiesta tramite CLI di generare script di configurazione per container sicuri. Esempio di comando:
    ```bash
    gemini "Crea un Dockerfile minimale e sicuro per un server MCP Python che non gira come root, e un docker-compose che mappa i secrets da un Vault esterno come variabili d'ambiente."
    ```
*   **Azione Umana Richiesta:** Validazione del Dockerfile e assegnazione effettiva dei ruoli IAM/RBAC per consentire al container di leggere i secret dall'infrastruttura.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 4 ore.
    *   *Tempo To-Be (GenAI):* 15 minuti.
    *   *Risparmio %:* 93%
    *   *Motivazione:* Generazione immediata di configurazioni infrastrutturali sicure secondo best-practice (es. utente non-root, mount sicuri), eliminando il rischio di errori umani nella configurazione dei container.

### Fase 3: Integrazione e Interfaccia Chatbot (Teams)
Il server MCP viene avviato e un bot aziendale viene configurato per connettersi a tale server MCP, permettendo agli utenti su Teams di richiamare i tool esposti in linguaggio naturale.
*   **Tool Principale Consigliato:** `copilot studio`
*   **Alternative:** 1. `Microsoft Teams (Chatbot UI)`, 2. `n8n`
*   **Modelli LLM Suggeriti:** OpenAI GPT-5.4 (motore di orchestratore dietro Copilot Studio)
*   **Modalità di Utilizzo:** Configurazione del bot all'interno di Copilot Studio, dichiarando l'endpoint del server MCP come estensione o sorgente dati.
    *Integrazione Teams:* Il bot configurato viene pubblicato come app direttamente su Microsoft Teams, fornendo un'interfaccia familiare ai dipendenti.
*   **Azione Umana Richiesta:** Test end-to-end simulando richieste utente da Teams e verificando nei log che il server MCP riceva solo i parametri attesi.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 6 ore (creazione integrazioni custom e polling manuale).
    *   *Tempo To-Be (GenAI):* 45 minuti.
    *   *Risparmio %:* 87%
    *   *Motivazione:* Il protocollo MCP standardizza l'integrazione. L'agente si aggancia nativamente ai server MCP comprendendo i tool esposti automaticamente, senza dover mappare ogni singola API a mano.

## 3. Descrizione del Flusso Logico
Il flusso adotta un'architettura **Single-Agent** potenziata dall'uso di tool esterni tramite standard MCP. L'agente LLM principale (Copilot Studio su Teams) funge da interfaccia conversazionale pura e non contiene logica di integrazione complessa: si limita ad analizzare la richiesta dell'utente (es. "A che punto è il ticket PROD-123?") e delega il recupero delle informazioni al Server MCP interno. Questo Server MCP, generato automaticamente da `visualstudio + copilot` ed eseguito in un container sicuro, riceve la chiamata, recupera le credenziali dal Secret Manager (mantenendo l'ambiente LLM all'oscuro delle password), interroga in modo sicuro il sistema legacy (Jira o DB), e restituisce il contesto pulito all'agente. Infine, l'agente formula la risposta finale per l'utente su Teams. Questa separazione netta garantisce la massima sicurezza e aderenza alle policy zero-trust.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
    A[Utente] -->|Interagisce tramite| B[Microsoft Teams UI]
    B -->|Frontend Chat| C[Copilot Studio / Agente LLM]
    C -->|Connessione MCP Standard| D[MCP Server Interno Docker]
    D -->|Richiesta Credenziali| E[Secret Manager aziendale]
    D -->|Query Sicura| F[(Database Legacy / Jira)]
    
    subgraph "DMZ Cloud LLM"
    C
    end
    
    subgraph "Rete Sicura Aziendale (On-Prem / Private Cloud)"
    D
    E
    F
    end
```

### 4.2 Process Diagram
```mermaid
flowchart TD
    Start([Inizio Richiesta Utente su Teams]) --> A{L'Agente capisce l'intento?}
    A -- No --> B[Chiede chiarimenti all'utente]
    A -- Sì --> C[Identifica tool MCP necessario]
    C --> D[Invia payload al Server MCP]
    D --> E{Parametri validi?}
    E -- No --> F[Errore validazione restituito all'Agente] --> B
    E -- Sì --> G[Il Server recupera Secret dal Vault]
    G --> H[Esegue la query su Jira/DB]
    H --> I[Restituisce i dati strutturati all'Agente]
    I --> J[L'Agente elabora la risposta per l'utente]
    J --> End([Fine])
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
    actor U as Utente (Teams)
    participant B as Copilot Studio (Agente)
    participant M as MCP Server
    participant S as Secret Manager
    participant DB as Jira/Legacy DB

    U->>B: "Dammi lo stato del ticket IT-404"
    B->>B: Analizza intento e scopre tool 'get_jira_ticket'
    B->>M: Chiama tool 'get_jira_ticket' (ticket_id="IT-404")
    activate M
    M->>M: Valida input tramite Pydantic/Zod
    M->>S: Richiede Token API Jira
    S-->>M: Restituisce Token
    M->>DB: GET /rest/api/2/issue/IT-404 (Auth: Bearer)
    DB-->>M: JSON con stato ticket
    M-->>B: Ritorna risultato pulito (Context)
    deactivate M
    B->>B: Genera risposta naturale basata sul contesto
    B-->>U: "Il ticket IT-404 è In Lavorazione e assegnato a Mario Rossi"
```

## 5. Guida all'Implementazione Tecnica
### Prerequisiti
- **IDE e Licenze:** Visual Studio Code con licenza per GitHub Copilot.
- **Infrastruttura:** Ambiente Docker installato sulla macchina di sviluppo o pipeline CI/CD pronta per i container.
- **Accessi:** Accesso a Copilot Studio e diritti da Amministratore per pubblicare bot sul tenant Microsoft Teams aziendale.
- **Sistemi Target:** Accesso in lettura/scrittura (API) a un tenant Jira/ServiceNow o un DB relazionale legacy di test.

### Step 1: Configurazione e Generazione in Visual Studio Code
1. Aprire Visual Studio Code e creare una cartella dedicata (es. `mcp-enterprise-server`).
2. Aprire il pannello laterale di Copilot Chat e incollare la richiesta di scaffolding indicata nella Fase 1.
3. Rivedere il codice generato (es. `server.py` o `app.ts`) e accettare i file.
4. Installare le dipendenze locali tramite terminale (es. `pip install mcp pydantic requests`).

### Step 2: Creazione Container e Policy Sicure
1. Dal terminale integrato, lanciare `gemini-cli` con il prompt indicato nella Fase 2.
2. Salvare i file `Dockerfile` e `docker-compose.yml` generati. Assicurarsi che nel Dockerfile sia presente il comando `RUN adduser --disabled-password appuser` e `USER appuser`.
3. Verificare le connessioni al Secret Manager testando il compose in locale con chiavi di mock.
4. Eseguire la build: `docker build -t mcp-enterprise-server .` e spingerla nel Container Registry aziendale.

### Step 3: Rilascio del Bot su Teams
1. Accedere a [Copilot Studio](https://copilotstudio.microsoft.com) con le proprie credenziali aziendali.
2. Creare un nuovo Copilot, assegnando un nome (es. "Enterprise Support Bot").
3. Spostarsi nella sezione **Azioni / Estensioni** o **Plugin**.
4. Aggiungere una nuova azione puntando all'endpoint esposto dal server MCP containerizzato (assicurarsi di abilitare SSE o i protocolli di trasporto supportati).
5. Configurare l'autenticazione lato Copilot per inviare un token o API Key verificata dal Server MCP.
6. Cliccare su **Pubblica**, selezionare il canale **Microsoft Teams** e approvare l'app nel tenant aziendale.

## 6. Rischi e Mitigazioni
- **Rischio 1: Prompt Injection per manipolare il Database** -> **Mitigazione:** Il Server MCP deve sanitizzare rigorosamente gli input e, nel caso di database relazionali, utilizzare *esclusivamente* query parametrizzate o un ORM sicuro. Nessuna query SQL cruda deve essere passata direttamente dall'LLM al motore del database.
- **Rischio 2: Esposizione di dati sensibili (Data Leak)** -> **Mitigazione:** Il Server MCP deve agire da filtro. Dal payload JSON restituito da Jira o dal DB, deve estrarre e inoltrare all'Agente LLM solo i campi essenziali (`status`, `summary`), scartando log completi o PII irrilevanti per l'obiettivo.
- **Rischio 3: Accesso non autorizzato all'endpoint MCP** -> **Mitigazione:** Distribuire il server MCP in una subnet privata accessibile solo dagli IP dell'infrastruttura di Copilot Studio, e rinforzare la sicurezza con un'autenticazione mutua (mTLS) o API Key robusta generata dal Secret Manager.