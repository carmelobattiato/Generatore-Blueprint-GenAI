# Blueprint GenAI: Efficentamento del "Design Backup e Retention"

## 1. Descrizione del Caso d'Uso
**Categoria:** Architecture & Design
**Titolo:** Design Backup e Retention
**Ruolo:** Storage & Backup Architect
**Obiettivo Originale (da CSV):** Progettazione delle politiche di salvataggio dei dati aziendali. Definizione della frequenza di backup (giornalieri, settimanali, mensili), della tipologia (completi, incrementali), implementazione di storage immutabili contro i ransomware e calcolo del periodo di conservazione normativo.
**Obiettivo GenAI:** Automatizzare la creazione di documenti di policy di backup e schemi tecnici di retention, trasformando i requisiti di business e normativi in configurazioni operative e report di conformità tramite un'interfaccia guidata.

## 2. Fasi del Processo Efficentato

### Fase 1: Raccolta Requisiti e Vincoli (Ingestion)
L'architetto interagisce con un bot su Teams per inserire i parametri critici: tipologia di dati (es. Database SQL, File Share), RPO/RTO desiderati, normative di riferimento (GDPR, DORA, NIS2) e volumi stimati.
*   **Tool Principale Consigliato:** `Copilot Studio` (pubblicato su **Microsoft Teams**)
*   **Alternative:** 1. `n8n` (form trigger), 2. `Accenture Amethyst`
*   **Modelli LLM Suggeriti:** `Google Gemini 3.1 Pro` (tramite API integrata in Copilot Studio)
*   **Modalità di Utilizzo:** Configurazione di un "Backup Design Assistant" che guida l'utente con domande strutturate.
    *   **Bozza System Prompt:**
        ```text
        Sei un esperto Storage & Backup Architect. Il tuo compito è raccogliere i requisiti per un nuovo piano di backup. 
        Chiedi all'utente: 1. Criticità del dato (Tier 1-3), 2. RPO e RTO richiesti, 3. Vincoli normativi (es. 10 anni per dati finanziari), 4. Presenza di requisiti di Immutabilità/Air-gap. 
        Una volta raccolti, sintetizza i dati e inviali al workflow di generazione policy.
        ```
*   **Azione Umana Richiesta:** Inserimento dei parametri di business e tecnici iniziali.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 2 ore (riunioni e raccolta mail)
    *   *Tempo To-Be (GenAI):* 10 minuti
    *   *Risparmio %:* 92%
    *   *Motivazione:* Eliminazione di iterazioni via email e standardizzazione immediata dell'input.

### Fase 2: Elaborazione Strategia e Calcolo Retention
Il motore AI analizza i dati raccolti, suggerisce la tipologia di backup (Synthetic Full, Incremental Forever), calcola la finestra di retention ottimale e propone l'architettura di storage (es. S3 Object Lock per immutabilità).
*   **Tool Principale Consigliato:** `n8n` (Orchestratore)
*   **Alternative:** 1. `Google Antigravity`, 2. `gemini-cli`
*   **Modelli LLM Suggeriti:** `Google Gemini 3 Deep Think` (per ragionamento complesso su calcoli di storage e incrocio normative)
*   **Modalità di Utilizzo:** Workflow n8n che riceve l'input da Teams, interroga un database di "Best Practices di Backup" (via RAG su SharePoint) e produce la strategia tecnica.
*   **Azione Umana Richiesta:** Revisione tecnica della strategia proposta (validazione RPO/RTO calcolati).
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 4 ore (calcoli manuali e analisi normative)
    *   *Tempo To-Be (GenAI):* 5 minuti
    *   *Risparmio %:* 98%
    *   *Motivazione:* L'AI applica istantaneamente pattern di design predefiniti e calcoli volumetrici complessi.

### Fase 3: Generazione Documentazione e Policy
Produzione automatica del documento di "Backup Policy" in formato Word/PDF e salvataggio su SharePoint.
*   **Tool Principale Consigliato:** `Accenture Amethyst` (per editing finale e formattazione enterprise)
*   **Alternative:** 1. `n8n` (con nodo Google Docs/Office 365), 2. `Claude-code` (per generare script di configurazione job)
*   **Modelli LLM Suggeriti:** `Anthropic Claude 4.6 Sonnet` (eccellente per la stesura di documenti tecnici formali)
*   **Modalità di Utilizzo:** Generazione di un file Markdown convertito in PDF.
*   **Azione Umana Richiesta:** Firma e approvazione finale del documento.
*   **Stima Reale di Efficienza:** 
    *   *Tempo As-Is (Manuale):* 3 ore (scrittura e formattazione)
    *   *Tempo To-Be (GenAI):* 2 minuti
    *   *Risparmio %:* 99%
    *   *Motivazione:* Generazione istantanea basata su template aziendali.

## 3. Descrizione del Flusso Logico
Il flusso è progettato come un approccio **Single-Agent** orchestrato da **n8n**. L'utente avvia il processo su **Microsoft Teams** interagendo con un bot creato in **Copilot Studio**. Il bot raccoglie i dati e li invia tramite Webhook a un workflow **n8n**. Qui, un agente basato su **Gemini 3.1 Pro** processa i dati, consulta le policy aziendali salvate su **SharePoint** (usando un approccio RAG semplificato o MCP per accedere ai file) e genera la proposta di backup. Il risultato viene inviato nuovamente su Teams per l'approvazione umana e, una volta confermato, il documento finale viene archiviato automaticamente.

## 4. Diagrammi UML (Mermaid.js)

### 4.1 Architecture Diagram
```mermaid
graph TD
  User((Storage Architect)) --> Teams[Microsoft Teams UI]
  Teams --> CS[Copilot Studio Bot]
  CS --> N8N[n8n Orchestrator]
  N8N --> Gemini[Gemini 3.1 Pro API]
  N8N --> SP[SharePoint Online]
  SP -- RAG Context --> Gemini
  Gemini -- Generated Policy --> N8N
  N8N -- Final PDF/Doc --> SP
  N8N -- Notification --> Teams
```

### 4.2 Process Diagram
```mermaid
flowchart TD
  Start([Inizio]) --> Input[Inserimento Requisiti su Teams]
  Input --> Logic{Analisi RPO/RTO & Compliance}
  Logic --> Draft[Generazione Draft Policy & Schema Retention]
  Draft --> Review{Revisione Umana?}
  Review -- No --> Draft
  Review -- Sì --> Save[Salvataggio su SharePoint]
  Save --> End([Fine - Policy Attiva])
```

### 4.3 Sequence Diagram
```mermaid
sequenceDiagram
  participant U as Architect
  participant T as Teams/Copilot
  participant N as n8n
  participant L as Gemini 3.1
  participant S as SharePoint

  U->>T: Inserisce dati (Tier, RPO, Retention)
  T->>N: Trigger Webhook (Payload)
  N->>S: Recupera Template & Normative
  S-->>N: Documenti Context
  N->>L: Genera Strategia Backup (Data + Context)
  L-->>N: Proposta Strategia & Documento
  N->>T: Invia Anteprima per approvazione
  U->>T: Click "Approva"
  T->>N: Conferma
  N->>S: Salva Documento Finale
  N->>T: Messaggio "Processo Completato"
```

## 5. Guida all'Implementazione Tecnica

### Prerequisiti
- Licenza **Microsoft 365** (Teams & SharePoint).
- Account **Copilot Studio**.
- Istanza **n8n** (self-hosted o cloud).
- API Key per **Google Gemini API**.

### Step 1: Configurazione Copilot Studio
1. Creare un nuovo bot "Backup Assistant".
2. Configurare i "Topics" per porre domande specifiche (Tipo dato, RPO, Giorni di retention).
3. Aggiungere un nodo "Call an action" che punta a un workflow Power Automate o direttamente a un Webhook n8n.

### Step 2: Sviluppo Workflow n8n
1. **Webhook Node:** Riceve il JSON con i dati da Teams.
2. **HTTP Request Node (Gemini):** Invia il prompt strutturato includendo i dati ricevuti.
    - *Prompt:* "Analizza questi requisiti: {{data}}. Genera una tabella di retention e una descrizione tecnica della politica di immutabilità basata su storage S3 Object Lock."
3. **Microsoft SharePoint Node:** Carica il testo generato in un file template o crea un nuovo file `.docx`.

### Step 3: Integrazione e Test
1. Pubblicare il bot su Teams.
2. Eseguire un test inserendo requisiti per un "Database Critico Finance".
3. Verificare che il calcolo della retention rispetti i vincoli normativi (es. 10 anni) e che il file compaia su SharePoint.

## 6. Rischi e Mitigazioni
- **Rischio:** Allucinazione sui calcoli dello storage necessario. -> **Mitigazione:** Inserire nel prompt formule matematiche deterministiche (es. Python Tool in n8n) per il calcolo dei TB invece di lasciarlo all'LLM.
- **Rischio:** Mancato rispetto di una normativa locale specifica. -> **Mitigazione:** Human-in-the-loop obbligatorio per la firma del documento e aggiornamento costante del repository SharePoint con le ultime leggi.
- **Rischio:** Dati sensibili nel prompt. -> **Mitigazione:** Utilizzo di istanze Enterprise (Amethyst o modelli su infrastruttura privata) che garantiscono il non riutilizzo dei dati per il training.
